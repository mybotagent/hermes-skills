---
name: wiki-auto-refresh
description: "매일 21:00 KST SOP Wiki 자동 갱신 — kanban 태스크 생성 → 위키 헬스 체크 → auto-fix → git push → 완료 보고"
version: 1.7.0
changelog:
  - "1.7.0 (2026-07-03): P11 — sibling README cross-reference (markdown link bare-name in subdir); scripts/markdown-link-audit.py"
  - "1.6.0 (2026-07-02): P10 — wikilink with explicit `.md` extension (false-negative bug in wikilink-audit.py fixed; auto-fix: strip trailing .md)"
  - "1.5.0 (2026-07-01): P9 bare-name wikilink class, refined P7 detection (suffix-first), `updated:` auto-fill procedure, scripts/wikilink-audit.py"
  - 1.4.0 (2026-06-30): P7/P8 pitfalls added — cross-domain wikilink false positives and code-block false positives
  - 1.3.0 (2026-06-29): P1-P6 pitfalls (git index corruption patterns)
  - 1.2.0 (2026-06-29): 2a-bis broken markdown link check
author: aiprofit
platforms: [linux]
metadata:
  hermes:
    tags: [wiki, auto-refresh, sop, cron, kanban, github]
    related_skills: [kanban-worker]
---

# Wiki Auto-Refresh

> **실행:** 매일 21:00 KST, cron + kanban 기반 (크론 모드에서는 kanban 생략 가능)
> **목적:** SOP Wiki(Karpathy LLM Wiki)를 자동 정리/갱신하고 GitHub에 동기화

## 실행 흐름

### 0. Pre-flight: Git 상태 점검 (권장)

**3단계(commit/push) 전에** 아래 점검을 한 번 수행. 이전 실행의 잔여 상태가 남아 있으면 push 단계에서 실패함.

```bash
cd ~/.hermes/wiki

# 1) Stale stash 확인 (이전 실행이 남긴 stash — 예: dawn-wiki-auto-stash)
git stash list
# 비어있지 않으면: 내용 확인 후 drop (작업 중 손실 위험 없음 확인)
git stash show -p stash@{0}  # 내용 확인
git stash drop stash@{0}     # 안전하면 drop

# 2) Diverged 상태 확인 (origin/main과 로컬이 갈라졌는지)
git status -sb  # "ahead" / "behind" / "diverged" 표시
# diverged면 일단 push 단계에서 rebase로 해결됨 — 다만 stash 잔재는 미리 제거
```

**왜 필요한가:** 이전 자동 동기화가 파일을 삭제하면서 stash에 보관하는 패턴이 있음 (`dawn-wiki-auto-stash`). 이 stash가 남아 있으면 후속 pull --rebase 시 "untracked working tree files would be overwritten" 오류로 막힘. 발견되는 대로 drop.

### 1. Kanban 태스크 생성 (크론 모드: 생략 가능)

Kanban 태스크 생성은 선택사항. 크론 모드에서 "kanban 태스크 생성/완료 불필요" 지시가 있다면 이 단계를 건너뛰고 2번으로 직행.

```python
kanban_create(
    title=f"wiki-auto-refresh-{date}",
    assignee="default",
    body=f"매일 21:00 KST wiki 정리. wiki/ 헬스 체크 + git push.",
)
```

### 2. Wiki 헬스 체크

다음을 순서대로 실행:

#### 2a. `index.md` 존재 확인 + 불일치 체크

**전제 조건**: root `index.md`가 반드시 존재해야 함. 없으면 먼저 생성.

**case A — index.md 없음:**
- `search_files(target="files", pattern="*.md", path="wiki/")`로 전체 .md 파일 수집
- 서브모듈(`logs/`, `subagents-library/` 등)은 제외
- AGENTS.md 구조 참고: `people/`, `infra/`, `analysis/`, `architecture/`, `code/`, `repos/`, `solopreneur/`, `watchlist/` 섹션
- **최상위 hub 페이지**(`hermes-trading-hub.md`)와 **하위 페이지**를 모두 포함하는 종합 카탈로그 생성
- 프론트매터 YAML에 `tags: ["wiki", "index", "navigation", "catalog"]` 포함

**case B — index.md 있음 (일반 케이스):**
- `read_file("wiki/index.md")` → 등록된 페이지 목록 파악
- `search_files(target="files", pattern="*.md", path="wiki/")` → 실제 .md 파일 목록
- index.md에 있지만 파일이 없는 페이지 → index.md에서 제거 (dead link)
- 파일은 있지만 index.md에 없는 페이지 → index.md에 추가 (적절한 섹션에)

#### 2a-bis. 깨진 markdown 링크 검사 (필수 — 2026-06-29 추가)

**index.md의 dead link 체크만으로는 부족.** wiki 본문 내 모든 `[text](path)` 마크다운 링크가 실제 파일로 resolve되는지 검증.

```python
# 검증 로직 (개념)
for each .md file (excluding submodules):
    for each [text](target) where target doesn't start with http/mailto/:
        if target has anchor (#) → strip anchor first
        resolve target relative to current file's directory
        if resolved path doesn't exist → BROKEN
```

**자주 발견되는 깨진 링크 패턴 (실제 사례):**
1. **`repos/*.md` → 다른 섹션 참조 시 `../` 누락** (가장 흔함)
   - `repos/foo.md`에서 `infra/gh-token.md` 링크 → 실제로는 `repos/infra/gh-token.md`로 resolve되어 깨짐
   - **수정:** `../infra/gh-token.md` (형제 디렉토리는 위로)
   - **sibling** (`repos/foo.md` → `repos/bar.md`): `repos/bar.md` (X) → `bar.md` (O, 경로 prefix 제거)
2. **index.md / README.md → root 파일 잘못된 경로**
   - `[hermes-trading-hub](repos/hermes-trading-hub.md)` (X) → `[hermes-trading-hub](hermes-trading-hub.md)` (O)
   - root의 hub/log 파일을 `repos/`에서 찾고 있는 흔한 실수

**수정 절차:** 한 파일당 `patch` 도구로 old_string → new_string 치환. `replace_all=False` (다른 파일의 같은 텍스트와 충돌 방지).

#### 2b. Orphan 페이지 확인
- `index.md`, `AGENTS.md`, `README.md`를 제외한 모든 페이지 검사
- `search_files(pattern='\\\\[\\\\[.*\\\\]\\\\]', path='wiki/', file_glob='*.md')`로 wikilink 사용처 검색
- **추가: markdown 링크 → wikilink 변환 감지** — hub 페이지에서 `[text](path)` 형식으로 wiki 페이지를 참조하는 링크가 있는지도 확인. markdown 링크는 wikilink 참조로 인식되지 않으므로, hub 페이지에 markdown 링크가 있고 해당 페이지가 orphan이면 → 기존 링크를 `[[text]]` 형식의 wikilink로 변환 (중복 추가 금지, 기존 링크를 대체)
- wikilink로 참조되지 않은 페이지 식별 (참고: markdown 링크 `[text](path)`는 wikilink가 아니므로 제외)
- Orphan 발견 시:
  1. **hub 페이지에 markdown 링크가 있는지 먼저 확인** → 있으면 wikilink로 변환 (추가가 아닌 대체)
  2. **hub 페이지에 wikilink 추가** (markdown 링크도 없었다면)
  3. hub 페이지가 적절하지 않으면 → 해당 내용과 관련된 페이지에 `[[page-name]]` 추가
  4. 정말 고아 페이지라면 (내용이 구식/관련 페이지 없음) → index.md에서 제거 + `_archive/`로 이동
  - **주의: "orphan"으로 보이지만 실제로 index.md/README.md에서 markdown 링크로 참조 중일 수 있음** → 삭제 전 반드시 index.md/README.md에서 참조 여부 확인. 참조 중이면 orphan이 아님 (잘못된 orphan 분류 = 데이터 손실)

#### 2c. Stale 페이지 확인
- **확인할 날짜 필드** (우선순위 순):
  1. 프론트매터 `updated:` (YAML)
  2. 프론트매터 `created:` (생성만 되고 업데이트 없는 페이지)
  3. 인라인 `**Last updated:**` (본문 텍스트)
- 30일 이상 지난 페이지 확인
- 너무 오래된 정보면 → 업데이트 필요 플래그 (리포트에 포함)
- **날짜 정보 없는 페이지 체크**: 프론트매터/inline 날짜가 없는 페이지는 git log로 대체 확인. 리포트에 "날짜 정보 없음 (N개)" 별도 항목으로 포함. (리포트 섹션 참고)
  - 옵션: git log `--format="%ai"` 날짜를 프론트매터 `updated:` 필드로 자동 삽입 가능 — 단, 30일 미만 페이지만 (오래된 페이지는 사람이 확인 필요)

**`updated:` 자동 채우기 절차 (선택적 — 2026-07-01 검증됨):**

날짜 필드가 누락된 페이지가 다수 발견되면 (실제 사례: 30개) 다음 절차로 일괄 채울 수 있음:

```python
# 1) For each .md file (skipping index/AGENTS/SCHEMA/README):
#    - frontmatter `updated: YYYY-MM-DD`가 이미 있으면 skip
#    - 없으면 git log -1 --format=%ai -- <file> 으로 최근 커밋일 조회
#    - 파일이 untracked면 file mtime fallback
#    - effective_date = max(fm_updated, inline_updated, git_date)
#    - effective_date가 30일 미만이면 → frontmatter에 `updated: <date>` 추가
#    - 30일 이상이면 → 자동 채우지 말고 리포트에 "수동 확인 필요"로 기재

# 2) Frontmatter가 없는 파일 → 새 frontmatter 블록을 첫 heading 위에 삽입
# 3) Frontmatter가 있는 파일 → 기존 블록 안에 `updated: YYYY-MM-DD` 줄 추가
```

**안전 가드 (필수):**
- `index.md`, `AGENTS.md`, `SCHEMA.md`, `README.md`는 **대상에서 제외** (스키마/랜딩 파일)
- 30일 이상 stale이면 자동 채우지 않음 (오래된 페이지는 사람이 내용 검토 후 결정해야 함)
- 추가 후 lint로 검증 (frontmatter YAML 문법 깨지면 안 됨)

**리포트:**
- "updated: 자동 채움: N개 페이지" 형태로 기재
- "30일+ stale로 수동 확인 필요: M개 페이지" 별도 표기

### 3. Git Push (GitHub 연동)

```bash
cd ~/.hermes/wiki
git add -A
git diff --cached --stat  # 변경사항 요약
if [ -n "$(git status --porcelain)" ]; then
  git commit -m "auto-sync $(date +%Y-%m-%d) 21:00 KST"
  git pull --rebase origin main 2>/dev/null || true
  git push origin main
fi
```

**⚠ Push 전 verify:** `git status`가 "clean"이고 origin/main이 "up to date"인지 확인 후 종료.

### 2d. (선택) Neo4j GraphRAG 인덱스 동기화

`wiki-knowledge-search` 스킬이 활성화되어 있고 Neo4j가 실행 중이면, wiki 변경사항을 Neo4j에 반영:

```bash
source ~/.venv-neo4j/bin/activate
python3 ~/hermes-wiki-super/.metagraph/indexer.py 2>&1
```

- indexer.py는 각 submodule의 git SHA를 비교 → 변경된 repo만 증분 스캔
- 신규 페이지 embedding 자동 생성 (fastembed multilingual MiniLM)
- 기존 페이지는 MERGE로 upsert (idempotent)
- Neo4j 미실행 시 조용히 skip (에러 무시)

**Pitfall:** DeepSeek/대부분 LLM API는 embedding endpoint가 없음.
반드시 fastembed 또는 OpenAI embeddings API 사용.

### 4. 완료 처리 및 리포트

```python
kanban_complete(
    summary=f"wiki auto-refresh 완료: N개 파일 변경, M개 orphan 처리",
    metadata={
        "files_changed": N,
        "orphans_fixed": M,
        "stale_pages": [...],
        "git_commit": "auto-sync YYYY-MM-DD 21:00 KST",
    },
)
```

Discord 리포트 형식:
```
📋 Wiki Auto-Refresh 완료 (21:00)

변경: N개 파일
Orphan 처리: M개 (wikilink 변환: X개)
Stale: K개 페이지
날짜 정보 없음: L개 페이지 (참고)

📎 GitHub: mybotagent/hermes-wiki
```

리포트 세부 항목:
- **변경**: git diff --stat 기준 파일 수
- **Orphan 처리**: wikilink 추가/변환 건수. markdown 링크→wikilink 변환 건수는 별도 표기
- **Stale**: 30일 이상 지난 페이지 목록
- **날짜 정보 없음**: 프론트매터/inline 날짜 필드가 누락된 페이지 수 (30일 미만이면 stale은 아니나 리포트에 기재)
- **깨진 markdown 링크 수정**: 2a-bis 단계에서 발견·수정한 건수 별도 표기 권장
- 변경사항이 없으면 간단히 "변경 없음"만 보고 (크론 모드) 또는 "[SILENT]" (크론 모드 지시 시)

## 주의사항
- `git push --force` 금지 — `pull --rebase` 우선
- `AGENTS.md`(schema)는 수정 금지 — 규칙 정의 파일
- `logs/`와 `subagents-library/`는 **submodule** — 이 저장소의 변경사항이 아님. `git status`에서 나타나면 무시
- **`find` 명령어로 파일 목록 조회 시** submodule 디렉토리를 반드시 제외: `find . -name '*.md' -not -path './logs/*' -not -path './subagents-library/*'`
- **`index.md` vs `INDEX.md`**: 파일명은 **소문자 `index.md`**가 정확 (AGENTS.md 스키마 규칙). `INDEX.md`(대문자)는 잘못된 명칭
- **변경사항이 없으면** `"[SILENT]"`로 응답 (크론 모드), 또는 "변경 없음"으로 간단히 완료
- **hub 페이지**는 wiki 루트의 `hermes-trading-hub.md` 또는 그에 준하는 최상위 네비게이션 페이지. orphan wikilink는 여기에 우선 추가
- **stale 날짜 포맷**: 프론트매터 `updated: YYYY-MM-DD`, `created: YYYY-MM-DD`, 본문 `**Last updated:** YYYY-MM-DD` 세 가지 포맷 모두 확인
- **빈 디렉토리**(`code/stock-analysis-toolkit/` 등)는 wiki 페이지가 아니므로 무시
- **README.md**는 프로젝트 랜딩 페이지 — AGENTS.md 구조와 중복되지 않도록 유지

## Pitfalls & Recovery (2026-06-29 추가)

자동 동기화를 여러 번 돌리면 git 인덱스가 비정상 상태로 빠질 수 있음. 아래 패턴을 모두 인식하고 복구 절차를 알고 있어야 함.

### P1. Assume-Unchanged 인덱스 오염 — 가장 위험

**증상:**
- `git status`가 "nothing to commit, working tree clean" 출력
- 하지만 `git ls-files`에 파일이 있고 `git diff HEAD -- <file>`은 "new file mode"라고 표시
- `git pull --rebase` 시 "untracked working tree files would be overwritten by checkout" 오류

**원인:** 이전 실행이 파일을 `git update-index --assume-unchanged`로 마크한 채 working tree에 남겨둠. 파일은 HEAD에서 삭제됐지만 인덱스에는 그대로 있고, working tree와 인덱스가 일치해서 `git status`는 깨끗하다고 판단.

**실제 사례 (2026-06-29):** `hermes-trading-hub.md`가 58ddec3 커밋에서 삭제됐지만 index에 assume-unchanged로 남아 있어 13시간 후의 동기화 실행을 막음.

**진단 절차:**
```bash
# 1) 의심 가는 파일의 인덱스 플래그 확인
git ls-files -v <file>  # "H" = assume-unchanged

# 2) HEAD에 실제로 있는지와 비교
git ls-tree HEAD <file>  # 비어있으면 HEAD에 없음
git diff HEAD -- <file>  # "new file mode" 나오면 인덱스만 있는 상태
```

**복구 절차 (안전 순서):**
```bash
# A) 플래그만 제거 (working tree 보존)
cd ~/.hermes/wiki
git update-index --no-assume-unchanged <file>
git status  # 이제 "deleted" 또는 "untracked"로 표시됨

# B) 그래도 깨끗하면 인덱스 강제 재빌드
rm .git/index
git reset HEAD  # HEAD 기준으로 인덱스 재생성

# C) 작업 트리에 복원 결정
#    - HEAD에 없고 untracked로 나타난 파일: 유용하면 commit, 아니면 삭제
#    - HEAD에 있고 "deleted"로 나타난 파일: git checkout -- <file>로 복원
```

**예방:** wiki-auto-refresh는 파일을 삭제할 때 `git rm` (working tree에서도 제거) 또는 `git rm --cached` (인덱스에서만 제거) 둘 중 하나로 결정적으로 처리. assume-unchanged로 마크한 채 방치하지 말 것.

### P2. Stale Stash (이전 실행 잔재)

**증상:** `git stash list`에 `dawn-wiki-auto-stash` 같은 항목이 있음. pull --rebase를 방해할 수 있음.

**원인:** 이전 dawn 자동 동기화(06:12 KST)가 파일 변경을 stash에 보관한 채로 종료.

**처리:**
```bash
git stash show -p stash@{0}  # 내용 확인 — 삭제된 파일 diff면 안전
git stash drop stash@{0}     # 안전 확인 후 drop
```

### P3. 깨진 Submodule 엔트리 (Pre-existing)

**증상:** `git status`가 `deleted: code/stock-analysis-toolkit` 표시. HEAD에는 submodule (mode 160000)로 등록돼 있지만 working tree에는 없고, .gitmodules에도 없음, commit object도 unreachable.

**예시 (2026-06-29):** `code/stock-analysis-toolkit` — HEAD 모드 160000, .gitmodules 미등록, commit `a5dd3e9c...` "bad object" 오류.

**처리:** **wiki-auto-refresh 범위 밖.** Pre-existing 문제로 간주하고 무시. 사용자에게 별도 정리가 필요함을 리포트에 기재. `git rm`으로 정리하면 submodule 참조가 사라져 또 다른 문제 발생 가능.

### P4. Working Tree에 있는 "삭제된" 파일의 모호한 상태

**증상:** HEAD에는 없고 working tree에만 있는 파일. `git add`가 "already up to date" 출력, `git status` clean.

**판단 기준:**
1. 파일이 index.md 또는 README.md에서 참조됨 → **살려야 함** → `git add`로 명시적 stage → commit (HEAD 복원)
2. 어디서도 참조 안 됨 → 진짜 orphan → 삭제 (git rm)

**주의:** "orphan 페이지"로 자동 분류·삭제하기 전에 **반드시** index.md / README.md의 markdown 링크에 참조되는지 확인할 것. markdown 링크는 wikilink 검사에서 잡히지 않음 → orphan 오분류 → 데이터 손실.

### P5. Force-Pushed Remote와 Diverged

**증상:** `git status -sb`가 "diverged" 표시. push 거부됨.

**처리:** `git pull --rebase origin main`이 정상 작동 (P1~P3가 해결됐다는 전제). 그 후 `git push origin main`. `git push --force`는 절대 금지.

### P6. `git rm --cached`가 의도치 않은 staged change 생성

**증상:** `git rm --cached <file-A>` 후 `git status`에 <file-B>가 "deleted"로 표시됨 (이전에 깨끗했을 때).

**원인:** 인덱스가 이미 오염된 상태(P1)에서 `git rm --cached`가 부수 효과를 일으킴.

**해결:** P1의 "B) 강제 재빌드" 절차로 인덱스 재구축 후 재시도.

## 빠른 트리아지 순서

Push 실패 시 아래 순서로 점검 (가장 흔한 원인부터):

1. `git stash list` → 비우기
2. `git status -sb` → diverged / ahead / behind 상태 확인
3. `git ls-files -v | grep '^H '` → assume-unchanged 잔재 (P1)
4. P1 진단·복구
5. `rm .git/index; git reset HEAD` (최후의 수단 — 인덱스 재빌드)
6. `git pull --rebase origin main`
7. `git push origin main`

## 추가 Pitfall (2026-06-30)

### P7. Cross-Domain Wikilink — 다른 위키 레포로의 의도된 참조

**증상:** hub 페이지(`hermes-trading-hub.md`)의 wikilink 검사에서 `[[harness-engineering-hub]]`, `[[macro-strategy]]`, `[[macro-indicators-hub]]`, `[[schedule-calendar-hub]]` 등이 "unresolved"로 표시됨. 하지만 이 페이지들은 **다른 위키 레포**(예: `harness-engineering-wiki`, `macro-indicators-hub` 등)에 존재하는 **의도된 cross-domain 참조**.

**원인:** Hermes 위키는 여러 레포로 나뉘어 있고, hub 페이지가 다른 레포의 페이지를 wikilink로 참조함 (예: "Related Wikis (Cross-Domain)" 섹션). 로컬 wikilink resolver는 현재 레포만 보기 때문에 false positive 발생.

**판단 기준 — broken이 아닐 가능성이 높은 시그널 (우선순위 순):**
1. **(가장 강함) wikilink 타겟이 `-hub`, `-strategy`, `-indicators-hub`, `-calendar-hub` 같은 suffix를 가짐** → cross-domain 허브 가능성 매우 높음
2. wikilink가 `Related Wikis`, `Cross-Domain`, `External`, `See also` 같은 **명시적 섹션**에 위치
3. wikilink가 AGENTS.md / SCHEMA.md / README.md에 등록된 "외부 위키" 목록에 포함
4. wikilink가 다른 위키 레포의 README.md에 실제로 존재 (cross-repo 확인 필요)

**2026-07-01 정밀화:** suffix check는 섹션 위치와 무관하게 작동해야 함. 실제 사례에서 `[[macro-strategy]]`는 Analysis Methodologies 섹션(섹션명은 "cross-domain"이 아님)에 있었지만, suffix(`-strategy`)로 cross-domain으로 정확히 식별됨. 즉 **suffix는 위치 독립적**, 섹션은 보조 시그널.

**처리:**
- 위 시그널 중 하나라도 해당되면 → **broken 아님**, 리포트에 "Cross-domain 참조: N개"로 별도 표기
- 시그널이 없고 wikilink가 hub/분류 페이지에 없으면 → 진짜 broken 가능성 → 리포트에 포함
- 시그널 분류 결과를 모를 때는 **suffix check만이라도 적용** (위양성보다 위음성이 안전)

**실제 사례:**
- (2026-06-30) `hermes-trading-hub.md`에 4개의 unresolved wikilink → 모두 cross-domain 의도된 참조 — 자동 수정하지 않고 "Cross-domain 참조"로 분류
- (2026-07-01) 동일 파일에 6개 cross-domain (suffix로 식별) + 25개 bare-name(P9, 다른 이슈) → P9는 auto-fix, cross-domain은 유지

### P8. Wikilink/Markdown 링크 False Positive — 문서 내 코드 예시

**증상:** `AGENTS.md`, `SCHEMA.md`, `infra/neo4j-local.md` 같은 페이지가 broken wikilink로 표시됨. 실제 파일을 보면 `[[link]]`, `[[wikilink]]` 같은 **문법 예시**가 backtick 코드 블록이나 Cypher 쿼리 예시 안에 등장.

**원인:** 정규식 `\[\[([^\]]+)\]\]`이 코드 블록 내부의 텍스트도 매치함. 이 패턴들은 "이런 식으로 wikilink를 작성한다"는 문법 설명일 뿐 실제 참조가 아님.

**흔한 false positive 위치:**
1. **마크다운 문법 설명** — "wikilink 형식: `[[page-name]]`" 같은 문서
2. **Cypher / GraphQL 쿼리 예시** — `(:Page)-[:LINKS {type: "wikilink"}]->(:Page)` 같은 코드
3. **JSON / YAML 예시** — frontmatter 설명, `related: ["..."]` 예시
4. **테스트/스키마 문서** — lint 규칙 설명이 wikilink 패턴을 보여줄 때

**처리:**
- wikilink 검사 시 **코드 블록(``` 또는 indented 4-space)을 먼저 제거**하거나
- 검사 대상을 wikilink 매치 후 **백틱 내부 여부 확인** (`\`...\`` 사이에 있는지)
- 또는 false positive로 분류된 페이지를 수동 확인 후 리포트에서 제외

**간단한 해결 (정규식 기반):**
```python
import re
# 코드 블록 제거
content_no_code = re.sub(r'```[\s\S]*?```', '', content)
content_no_code = re.sub(r'`[^`]+`', '', content_no_code)
# 그 다음 wikilink 검사
WIKILINK_RE = re.compile(r'\[\[([^\]]+)\]\]')
```

**주의:** AGENTS.md와 SCHEMA.md는 스키마 정의 파일이므로 검사 대상에서 **제외**해도 안전함 (수정 금지 영역). 단, 그 안의 예시 코드가 깨지면 lint의 false positive가 됨.

### P9. Bare-Name Wikilink — 디렉토리 prefix 누락 (2026-07-01 추가)

**증상:**
- hub 페이지(`hermes-trading-hub.md`)에서 `[[aiprofit]]`, `[[discord-gateway]]`, `[[cron-jobs]]`, `[[stock-rating-system]]` 같은 **bare-name wikilink**가 대량으로 깨짐 (실제 사례: 25개 한 번에 발견).
- 파일은 분명히 존재하지만 wikilink에 디렉토리 prefix가 없어 resolver가 wiki 루트에서 찾으므로 실패.

**원인:** Obsidian/Logseq 등 일부 위키 툴은 bare-name wikilink를 vault-wide basename resolver로 처리하지만, 우리 환경의 정적 wikilink resolver는 디렉토리 prefix가 없으면 wiki 루트에서만 검색함 → `people/aiprofit.md`를 찾지 못함.

**판단 기준 — auto-fix 가능:**
1. `[[aiprofit]]` 같은 bare-name wikilink가 broken으로 나옴
2. wiki 전체에서 basename(`aiprofit`)으로 검색하면 `people/aiprofit.md` 한 곳에만 존재
3. 매칭이 unique → 안전하게 `[[people/aiprofit]]`로 자동 변환 가능
4. basename 매칭이 0건 → 진짜 broken (P7 cross-domain 후보 재확인)
5. basename 매칭이 2건 이상 → 모호함, 사람이 결정 필요 (자동 수정 금지)

**실제 사례 (2026-07-01):** `hermes-trading-hub.md`에서 bare-name wikilink 25개 발견 — 모두 unique basename 매칭으로 안전하게 auto-fix. plus `[[macro-strategy]]`는 suffix(`-strategy`)로 cross-domain 식별.

**수정 절차:**
```python
import os, re
from pathlib import Path
from collections import defaultdict

wiki = Path.home() / ".hermes/wiki"
# 1) Build basename index
basename_idx = defaultdict(list)
for root, dirs, files in os.walk(wiki):
    dirs[:] = [d for d in dirs if d not in {"logs", "trade-pipeline", "subagents-library", ".git"}]
    for f in files:
        if f.endswith(".md"):
            basename_idx[f[:-3]].append(f)  # e.g. "aiprofit" -> "people/aiprofit.md"

# 2) Scan wikilinks
WIKILINK_RE = re.compile(r'\[\[([^\]]+)\]\]')
for page in wiki.rglob("*.md"):
    if page.name in ("AGENTS.md", "SCHEMA.md"):
        continue
    content = page.read_text()
    content_no_code = re.sub(r"```[\s\S]*?```|`[^`\n]+`", "", content)
    for m in WIKILINK_RE.finditer(content_no_code):
        target = m.group(1).split("#")[0].strip()
        # Skip if it has a slash (already has path prefix) or already resolves
        if "/" in target or (wiki / (target + ".md")).exists():
            continue
        # Skip cross-domain suffixes
        if any(target.endswith(s) for s in ("-hub", "-strategy", "-indicators-hub", "-calendar-hub")):
            continue
        # Try basename
        if len(basename_idx[target]) == 1:
            real = basename_idx[target][0][:-3]  # strip .md
            print(f"  {page.name}: [[{target}]]  ->  [[{real}]]")
```

**예시 (실제 출력):**
```
hermes-trading-hub.md: [[aiprofit]]  ->  [[people/aiprofit]]
hermes-trading-hub.md: [[discord-gateway]]  ->  [[infra/discord-gateway]]
hermes-trading-hub.md: [[stock-rating-system]]  ->  [[analysis/stock-rating-system]]
```

**도구:** `scripts/wikilink-audit.py`가 이 검사 + cross-domain + broken wikilink을 한 번에 수행. cron 실행 시 첫 단계로 호출하면 사람이 보는 보고서가 명확해짐.

### P10. Wikilink with Explicit `.md` Extension — False-Negative Audit Bug (2026-07-02 추가)

**증상:**
- wiki 본문에 `[[architecture/hybrid-ai-stack.md]]`, `[[infra/cron-jobs.md]]` 같이 **target에 이미 `.md`가 포함된 wikilink**가 대량으로 깨짐 (실제 사례: 7개 한 번에 발견).
- 파일은 분명히 존재하지만 실제 resolver가 `target + ".md"`로 lookup하므로 `wiki/architecture/hybrid-ai-stack.md.md`를 찾으러 가서 실패.
- **기존 `scripts/wikilink-audit.py`가 이 패턴을 false-negative로 통과시킴** (v1.5.0 시점 버그): `target_with_md = raw if raw.endswith(".md") else raw + ".md"` 로직이 `.md`가 이미 있으면 `target + ".md"` append를 생략해서 `wiki/foo.md`를 그대로 검사 → 파일이 존재하므로 "OK"로 분류. **이게 함정.**

**원인:**
- 인간 작성자는 `[[path/to/page.md]]`를 "정확한 경로"라고 생각해서 적음.
- 실제 wikilink resolver는 `[[target]]`을 `wiki/<target>.md`로 resolve하므로 `.md`를 한 번 더 붙이면 안 됨.
- audit 스크립트가 두 케이스를 동일하게 취급하면서 false-negative 발생.

**실제 사례 (2026-07-02):**
```
architecture/hermes-vs-chatbot.md:
  - [[architecture/hybrid-ai-stack.md]]   → 404
  - [[infra/cron-jobs.md]]                 → 404
  - [[infra/discord-gateway.md]]           → 404
infra/higgsfield-mcp.md:
  - [[architecture/hermes-vs-chatbot.md]]  → 404
  - [[architecture/hermes-vs-chatbot.md#스킬-과적합의-그늘과-매뉴얼-관리법]]  → 404 (앵커 포함)
  - [[infra/cron-jobs.md]]                 → 404
  - [[infra/discord-gateway.md]]           → 404
```

**판단 기준 — auto-fix 가능:**
1. `[[path/to/page.md]]` 또는 `[[path/to/page.md#anchor]]` 패턴 발견
2. `path/to/page` (strip `.md`)가 실제 파일로 resolve됨
3. anchor가 있어도 동일하게 strip만 하면 됨
4. → 안전하게 `[[path/to/page]]` 또는 `[[path/to/page#anchor]]`로 자동 변환

**수정 절차:**
```python
# wikilink-audit.py에서 .md가 있는 경우 새 finding 카테고리(MDEXT)로 보고
WIKILINK_RE = re.compile(r'\[\[([^\]]+)\]\]')

for m in WIKILINK_RE.finditer(content_no_code):
    raw_with_anchor = m.group(1).strip()
    raw = raw_with_anchor.split("#")[0]
    if not raw:
        continue
    if raw.endswith(".md"):
        # MDEXT: strip .md and re-check
        stripped = raw[:-3]
        anchor = raw_with_anchor[len(raw):]  # preserve "#anchor"
        if (wiki / (stripped + ".md")).exists():
            findings["mdext"].append((m.group(0), raw_with_anchor, stripped + anchor))
            continue
        # else: still BROKEN after strip → original audit
        ...
```

**수정 결과 (실제):**
```
[[architecture/hybrid-ai-stack.md]]      →  [[architecture/hybrid-ai-stack]]
[[infra/cron-jobs.md]]                    →  [[infra/cron-jobs]]
[[architecture/hermes-vs-chatbot.md#X]]  →  [[architecture/hermes-vs-chatbot#X]]  (앵커 보존)
```

**핵심 교훈:** wikilink 검사 시 `target + ".md"` 룰을 일관되게 적용할 것. `.md`가 이미 있는지를 분기하면 안 됨. audit 스크립트(v1.6.0+)는 `.md`가 있으면 **MDEXT** 카테고리로 보고하고, fix는 `.md` strip + anchor 보존.

**audit-script 패치 위치:** `scripts/wikilink-audit.py`의 `audit_file()` 함수 — `target_with_md = raw if raw.endswith(".md") else raw + ".md"` 라인을 제거하고, `.md`로 끝나면 무조건 `raw[:-3]`로 strip한 후 lookup. 앵커는 `m.group(1)`에서 `.split("#")[0]` 이전에 보존.

### P11. Sibling README Cross-Reference — 형제 디렉토리 페이지 잘못 참조 (2026-07-03 추가)

**증상:**
- `architecture/how-to-use-hermes/README.md` (서브디렉토리 README)에서 `[hermes-vs-chatbot.md](hermes-vs-chatbot.md)`, `[hermes-memory-pipeline.md](hermes-memory-pipeline.md)` 같이 **bare-name**으로 형제 디렉토리 페이지를 참조.
- 실제로는 `architecture/hermes-vs-chatbot.md`가 존재하지만, `how-to-use-hermes/hermes-vs-chatbot.md`로 resolve되어 깨짐.
- **wikilink 검사 (P7/P9/P10)에서는 잡히지 않음** — 이 패턴은 wikilink `[[...]]`이 아니라 markdown 링크 `[text](path)`이고, bare-name은 P9 wikilink 검사 범위 밖.

**원인:**
- 새 multi-page 문서(예: `how-to-use-hermes/01-09.md`)를 만들 때 hub 역할을 하는 `README.md`를 서브디렉토리에 두고, 그 README가 같은 wiki의 다른 섹션 페이지를 bare-name으로 참조.
- 작성자 입장에서는 "wiki 어디든 있을 테니 자동으로 resolve되겠지"라는 막연한 가정. 하지만 markdown link는 항상 **현재 파일의 디렉토리 기준**으로 resolve됨.

**판단 기준 — auto-fix 가능:**
1. `[text](bare-filename.md)` 또는 `[text](sibling-path.md)` 패턴이 서브디렉토리 파일에서 발견
2. target을 (현재 파일의 부모 디렉토리 기준)으로 resolve했을 때 실제 파일이 존재
3. → `../` prefix 추가하여 정정 (anchor 보존)

**수정 절차 (실제 사례, 2026-07-03):**
```python
import re
from pathlib import Path

wiki = Path.home() / ".hermes/wiki"
MD_LINK = re.compile(r'\[([^\]]+)\]\(([^)]+)\)')
EXCLUDE = {"logs", "subagents-library", ".git", "trade-pipeline"}
CODE_BLOCK = re.compile(r'```[\s\S]*?```')
INLINE_CODE = re.compile(r'`[^`\n]+`')

for p in wiki.rglob("*.md"):
    rel = p.relative_to(wiki)
    if any(part in EXCLUDE for part in rel.parts):
        continue
    if p.name in ("AGENTS.md", "SCHEMA.md"):
        continue
    content = p.read_text()
    content_no_code = CODE_BLOCK.sub("", content)
    content_no_code = INLINE_CODE.sub("", content_no_code)
    page_dir = p.parent
    for m in MD_LINK.finditer(content_no_code):
        text, target = m.group(1), m.group(2)
        if target.startswith(("http://", "https://", "mailto:", "#")):
            continue
        target_path, _, anchor = target.partition("#")
        if not target_path:
            continue
        resolved = (page_dir / target_path).resolve()
        if resolved.exists():
            continue  # OK
        # Try parent directory (../)
        resolved_parent = (page_dir.parent / target_path).resolve()
        if resolved_parent.exists():
            new_target = f"../{target_path}" + (f"#{anchor}" if anchor else "")
            print(f"  {rel}: [{text}]({target}) -> [{text}]({new_target})")
```

**실제 수정 결과 (2026-07-03):**
```
architecture/how-to-use-hermes/README.md: [hermes-vs-chatbot.md](hermes-vs-chatbot.md) -> [hermes-vs-chatbot.md](../hermes-vs-chatbot.md)
architecture/how-to-use-hermes/README.md: [hermes-memory-pipeline.md](hermes-memory-pipeline.md) -> [hermes-memory-pipeline.md](../hermes-memory-pipeline.md)
```

**핵심 교훈:**
- 2a-bis 검사(깨진 markdown 링크)는 wikilink 검사(P7/P9/P10) 결과가 0이 나와도 **반드시 별도 실행**할 것 — 두 종류의 링크는 서로 다른 false-negative surface를 가짐.
- multi-page 문서 README 작성 시 같은 wiki의 다른 섹션 페이지를 참조할 때는 항상 `../<dir>/<file>.md` 형식 사용 (현재 파일 디렉토리 기준 아님).
- frontmatter `related:` 필드는 절대 경로(`architecture/hermes-vs-chatbot.md`)를 쓰지만 본문 markdown link는 상대 경로 — 두 컨벤션을 섞지 말 것.
- P9 (bare-name wikilink fix)와 P11 (bare-name markdown link fix)의 **시그널은 같지만 fix 메커니즘이 다름**:
  - P9: wikilink `[[foo]]` → `[[dir/foo]]` (디렉토리 prefix 추가)
  - P11: markdown `[foo](foo.md)` → `[foo](../foo.md)` (../ prefix 추가)

**audit-script 패치 위치:** `scripts/wikilink-audit.py`는 wikilink 전용이므로 P11은 별도 — `scripts/markdown-link-audit.py` 사용. 두 검사 결과를 리포트에 별도 표기.

## 참고 자료
- 위키 구조/스키마: `wiki/AGENTS.md`, `wiki/SCHEMA.md`
- 프론트매터 일관성 분석 (별도 세션): `wiki/_frontmatter_report.md`
- GraphRAG 인덱서: `wiki-knowledge-search` 스킬 참고
- **wikilink 자동 검사**: `scripts/wikilink-audit.py` (broken / cross-domain / bare-name / .md-extension 분류; P7/P9/P10 모두 자동 감지)
- **markdown link 자동 검사**: `scripts/markdown-link-audit.py` (P11 sibling cross-reference; --fix 옵션으로 일괄 수정)
- **세션 노트 (누적)**: `references/session-notes.md` — 일자별 발견/적용/커밋 해시

# Session Notes — wiki-auto-refresh runs

누적 세션 노트. 각 항목은 (날짜, 발견, 적용) 형식.

## 2026-07-03 (P11 패턴 출현)

**발견:**
- `architecture/how-to-use-hermes/README.md` 35, 36번 줄에서 bare-name markdown link 2건 깨짐:
  - `[hermes-vs-chatbot.md](hermes-vs-chatbot.md)` — sibling 디렉토리 페이지를 bare-name으로 참조
  - `[hermes-memory-pipeline.md](hermes-memory-pipeline.md)` — 동일 패턴
- `how-to-use-hermes/` 서브디렉토리(2026-07-03 신규 생성된 multi-page 가이드)의 README.md가 같은 wiki의 다른 섹션을 bare-name으로 참조.
- **wikilink 검사 (P7/P9/P10) 결과는 0 broken이었으나** markdown link 검사로만 발견됨 — 두 종류의 링크는 서로 다른 false-negative surface.

**적용:**
- P11 pitfall 신규 추가 (SKILL.md v1.7.0) — 형제 README cross-reference, `../` prefix 추가 메커니즘.
- `scripts/markdown-link-audit.py` 신규 — P11 자동 감지 + `--fix` 옵션으로 일괄 수정.
- P9 vs P11 구분 정리 (SKILL.md 본문): 같은 bare-name 시그널이지만 fix 메커니즘이 다름.
  - P9: wikilink `[[foo]]` → `[[dir/foo]]` (디렉토리 prefix)
  - P11: markdown `[foo](foo.md)` → `[foo](../foo.md)` (`../` prefix)
- 실제 수정 commit: `b1eed3e auto-sync 2026-07-03 21:00 KST: fix broken markdown links in how-to-use-hermes/README`.

**부수 발견:**
- `how-to-use-hermes/01-09.md` 9개 서브페이지는 모두 0일 stale — `README.md` 인덱스 테이블에서 참조되어 orphan 아님.
- `raw/memory-pipeline-design-2026-07-02.md` + `raw/sync/...` + `architecture/memory-snapshots/...` 3개 페이지가 index.md에는 없지만 모두 `hermes-memory-pipeline.md`에서 markdown link로 참조됨 — orphan 아님.
- 30일 경계 페이지 5개 (정확히 30일): 자동 채우기 불필요, 임계 미만. 다음 점검 시 stale로 진입.

**Cross-domain (유지):** 이번 실행에서도 `hermes-trading-hub.md`의 4개 cross-domain wikilink 정상 유지.

## 2026-07-02 (auto-refresh run)

**발견:**
- 7개 wikilink에 명시적 `.md` 확장자가 포함되어 broken 상태 (실제 resolver는 `target + ".md"`로 lookup하므로 `foo.md.md` 찾으러 가서 실패).
- 영향 파일: `architecture/hermes-vs-chatbot.md` (3개), `infra/higgsfield-mcp.md` (4개 — 1개는 `#anchor` 포함).
- `scripts/wikilink-audit.py` v1.5.0이 이 패턴을 false-negative로 통과시킴 (`target_with_md = raw if raw.endswith(".md") else raw + ".md"` 분기 때문에, `.md` 이미 있으면 `wiki/foo.md`를 그대로 검사 → 파일 존재로 OK 오인).

**적용:**
- P10 pitfall 신규 추가 (SKILL.md v1.6.0).
- `scripts/wikilink-audit.py` 패치: `.md`가 있으면 항상 strip한 후 lookup, `body != normalized`일 때만 `mdext` finding으로 보고. 앵커는 보존.
- 실제 수정 commit: `3e9645f fix(wiki): strip .md extension from 7 wikilinks`.

**부수 발견 (race condition):**
- cron 실행 도중(첫 pre-flight ~ 두 번째 status 사이) 사용자가 `271e571 arch: Hermes Memory Pipeline 4-Layer` 커밋을 manual로 push함.
- 첫 `git status -sb`에서는 `M index.md`, `?? architecture/hermes-memory-pipeline.md`, `?? raw/memory-pipeline-design-2026-07-02.md`로 uncommitted로 보였으나, commit 시점엔 모두 HEAD에 있었음.
- **교훈:** `git status`는 snapshot이므로 시간차로 stale할 수 있음. `git diff HEAD`로 working tree vs HEAD 직접 비교가 더 신뢰성 높음. cron에서는 큰 문제 없음 (작업 결과만 commit하면 됨).

**Cross-domain (유지):**
- `hermes-trading-hub.md`의 4개 wikilink (`[[harness-engineering-hub]]`, `[[macro-strategy]]`, `[[macro-indicators-hub]]`, `[[schedule-calendar-hub]]`)는 suffix 기반으로 cross-domain 식별되어 자동 수정 대상 아님. P7 패턴 정상 작동.

## 2026-07-01 (P9 패턴 출현)

`hermes-trading-hub.md`에서 bare-name wikilink 25개 발견 — 모두 unique basename 매칭으로 `[[people/aiprofit]]` 등 prefix 추가하여 auto-fix.

## 2026-06-30 (P7/P8 패턴 출현)

- P7: `hermes-trading-hub.md`의 4개 cross-domain wikilink — suffix(`-hub`, `-strategy`)로 식별.
- P8: `AGENTS.md`의 `[[link]]` 같은 문법 예시가 코드 블록 안에 있을 때 broken으로 오탐.

## 2026-06-29 (P1-P6 + 2a-bis)

- P1: assume-unchanged 인덱스 오염 — `hermes-trading-hub.md`가 58ddec3에서 삭제됐는데 index에 assume-unchanged로 남음.
- P2: dawn-wiki-auto-stash 잔재.
- 2a-bis: 깨진 markdown 링크 검사 추가.

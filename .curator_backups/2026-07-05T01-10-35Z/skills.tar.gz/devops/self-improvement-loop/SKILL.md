---
name: self-improvement-loop
description: Class-level methodology for self-reflective improvement cycles using the WHAT⇒WHETHER⇒WHAT⇒HOW framework. Use whenever proposing improvements to a running system (cron, config, agents), reviewing weekly/monthly operations, defining metrics, or designing meta-cognition loops. Anchored on the user's 단일공식 preference (single formula, no branching) and 가치 검증 선행 philosophy.
when_to_use: |
  - 사용자가 "시스템 개선/리뷰/자기반성" 루프를 원할 때
  - cron/agent 운영을 주기적으로 self-audit 해야 할 때
  - 메트릭/지표가 정말 가치를 측정하는지 의심할 때
  - "해야 할 것 같은 느낌" 항목을 걸러내야 할 때 (사용자 핵심 원칙)
  - Level 4 self-improving agent를 욕심내려 할 때 (반드시 한 발짝 물러서게)
allowed-tools: Read Write Glob Grep WebFetch Bash
model: opus
context: fork
---

# Self-Improvement Loop (자가 개선 루프)

## 핵심 철학 — 사용자 원칙

| 원칙 | 의미 |
|------|------|
| **단일공식 선호** | 4-phase 단일 공식. 예외/조건문 금지 |
| **가치 검증 선행** | 실행 전에 "이게 진짜 필요한가?" 평가부터 |
| **shiny object 거름** | "해야 할 것 같은 느낌" 항목 명시적 거부 |
| **Phase 독립** | 한 Phase = 한 사이클 = 한 사이즈 |
| **최종 승인 = 인간** | cron push 전 aiprofit 승인 필수 |

## 🔁 4-Phase 공식: WHAT ⇒ WHETHER ⇒ WHAT ⇒ HOW

```
T₀ = cron trigger (주 1회 또는 월 1회)
    │
    ▼
┌─────────────────────────────────────────────────┐
│  PHASE 1 · WHAT  (지난 주 실제로 일어난 일)       │
│  ──────────────────────────────────────────────  │
│  • cron 실행 이력 (id, 실행횟수, 성공률, 비용)    │
│  • delegate_task 호출 이력                        │
│  • Linear/Kanban 상태 변화                        │
│  • Discord 발송량 / 사용자 반응                    │
│  • 산출물 (wiki 갱신, 리포트, 알림)                │
│  ⇒ "quantified reality" — 감 없이 숫자로만        │
└─────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│  PHASE 2 · WHETHER  (측정 자체가 옳은가)          │
│  ──────────────────────────────────────────────  │
│  • 우리가 측정하는 KPI가 진짜 가치 신호인가?       │
│  • "해야 할 것 같은" 항목이 metrics에 들어있나?    │
│  • 사용자(aiprofit)가 실제로 얻은 가치는?         │
│  • missing metric: 우리가 안 보는 게 더 중요?     │
│  ⇒ "질문 없는 답 거부" — 단일공식이어도 metric은 의심 │
└─────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│  PHASE 3 · WHAT  (진짜로 측정/해야 할 것)         │
│  ──────────────────────────────────────────────  │
│  • 옳은 정의/메트릭 재진술                         │
│  • 폐기 지표 (정직하게 삭제)                       │
│  • 추가 지표 (검증된 신호만)                       │
│  • 단일공식 재확인 또는 진화                        │
│  ⇒ "shiny object 거름망" 통과 후만 채택           │
└─────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│  PHASE 4 · HOW  (다음 주 구체 실행안)             │
│  ──────────────────────────────────────────────  │
│  • 변경 대상 (cron_id / SOUL / config)            │
│  • 변경 내용 (diff-level 한 줄)                   │
│  • 검증 방법 (kpi delta 측정 어떻게)              │
│  • 리스크 평가 (blast radius)                     │
│  • 비용 (tokens/월) 추정                          │
└─────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│  GATE · 너의 결정 (자동 적용 X)                   │
│  ──────────────────────────────────────────────  │
│  □ 전부 적용                                      │
│  □ 부분 적용 (선택)                               │
│  □ 보류 (다음 주 재검토)                          │
│  □ 폐기 (반대로 가야 함)                          │
│  ⇒ HUMAN-IN-THE-LOOP — 자동 적용은 Level 4 함정  │
└─────────────────────────────────────────────────┘
```

## 🚦 5-Level 자동화 분류 (Level 4~5 금지 약속)

| Level | 명칭 | 가능성 | 사용자 약속 가능 |
|-------|------|--------|------------------|
| 1 | 단순실행 (cron 요약/알림) | ✅ 표준 | ✅ |
| 2 | 분석/생성 (요약/코드/리서치 초안) | ✅ 즉시 가능 | ✅ (이게 진짜 타겟) |
| 3 | 자율협업 루프 (multi-agent 회의) | ⚠️ PoC, $50+/월 | ⚠️ 가치 검증 후 |
| 4 | 장기 자율운영 (self-improving) | ❌ lab 데모 | ❌ 약속 금지 |
| 5 | 자율판단/책임 | ❌ 어디서나 금지 | ❌ 약속 금지 |

## 구현 매핑 (Hermes 인프라에 그대로 얹기)

| 컴포넌트 | 도구 | 너 자산을 어떻게 쓰나 |
|---------|------|---------------------|
| **Trigger** | `cronjob` tool | 매주 일 21:00 KST 또는 매월 1일 07:00 KST |
| **Phase 1: WHAT** | `terminal` + `read_file` | `state.db`, `kanban.db`, `agent.log`, Linear history |
| **Phase 2: WHETHER** | `delegate_task(goal="critic")` | critic subagent 호출 |
| **Phase 3: WHAT** | `delegate_task(goal="redefine")` | redefine subagent 호출 |
| **Phase 4: HOW** | `delegate_task(goal="redefine")` | config diff / cron 변경안 |
| **Gate** | Discord 배너 + Kanban | 자동 push X, 인간 승인 대기 |
| **Wiki 갱신** | `wiki_save` skill | 변경 이력 영속화 |

## Subagent 2종 정의 → see `templates/critic.md` and `templates/redefine.md`

## 📋 산출물 템플릿

```
═══════════════════════════════════════════════════
🔁 자체개선 루프 — YYYY-Wnn (YYYY-MM-DD ~ YYYY-MM-DD)
═══════════════════════════════════════════════════

[1] WHAT — 실제 작동량
─────────────────────
• Cron N건, 평균 X회/일 실제 발화, Y건 한 번도 안 돌음
• Delegate 호출 N건, 평균 Xk tokens/건, max Yk (한 건 spike)
• Linear 태스크 N건 중 M건 완료, 평균 X일 lag
• Discord 발송 N회, 사용자 반응률 X%
• 토큰 사용 Xk t/day 평균, $Y/일

[2] WHETHER — 메트릭 의심
──────────────────────────
✗ "[메트릭명]"은 신호 아님 — [이유]
✓ 진짜 신호 후보: [후보]
✗ 빠진 신호: [missing metric]

[3] WHAT — 진짜 정의
────────────────────
옳은 지표:
• [지표 1 — 정의]
• [지표 2 — 정의]

폐기 후보: [메트릭 목록]

[4] HOW — 이번 주 변경안
────────────────────────
① [변경 대상] →
   [변경 내용 한 줄]
   [blast-radius: low/medium/high, 검증: kpi delta]

② [변경 대상] →
   [변경 내용 한 줄]
   [blast-radius: ...]

③ ❌ 신규 — [제안] [보류]
   (데이터 N일 더 필요)

[5] 너의 결정 (필수)
────────────────────
□ a/b 모두 적용
□ ①만 적용
□ ①+② 적용
□ 모두 거절

═══════════════════════════════════════════════════
출처: [데이터 출처]
예상 토큰비: $X.XX
═══════════════════════════════════════════════════
```

## ⚠️ 5대 함정 (피할 것)

1. **자기개선 루프 = Level 4 함정**: ground-truth 없이 LLM이 자기 자신을 평가 → drift
2. **메타-메타-메타 recursion**: what ⇒ whether ⇒ what ⇒ whether... 무한. **단일 사이클 = 4단계 고정**, 깊이 제한
3. **메모리 비대화**: 사이클 누적으로 지표가 폭증 → pruning 필요 (월 1회)
4. **자동 적용**: cron push를 자동화 = Level 4. **반드시 인간 승인 게이트**
5. **과잉 약속**: "사람 없이 완전 자동 회사" 약속 → 신뢰 손상. **Level 2까지만 약속**

## Quick start (가장 작은 첫 사이클)

```
1. Trigger: 일요일 21:00 KST (위키 자동갱신 cron과 같은 시각)
2. 첫 subagent: critic만 (redefine는 추후)
3. 첫 입력: 이번 주 너 워크플로우 (1주만 분석)
4. 첫 산출: [1][2] 만. [3][4]는 두 번째 사이클부터
5. 결정은 너: 자동 push X
```

**단일 공식**: "한 번에 한 사이클". 사이클 자체를 단일 공식화하지.

## 핵심 takeaway

> **자가개선 = sharp advisor, CEO는 아님. 최종 결정 = 너.**
> **WHAT ⇒ WHETHER ⇒ WHAT ⇒ HOW. 4단계 고정, 자동 적용 금지, 가치 검증 통과만 채택.**
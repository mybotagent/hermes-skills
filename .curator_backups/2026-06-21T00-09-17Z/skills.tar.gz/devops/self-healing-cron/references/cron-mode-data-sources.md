# Cron Mode Data Sources (2026-06-16 검증)

cron 모드(HIGH 보안, pipe-to-interpreter 차단)에서 실제 동작 확인된 금융 데이터 소스.

## 환율 (open.er-api.com)
- 무료, 일 1,500회, SSL 지원
- 검증 완료: USD/KRW=1513.37, EUR/USD=1.1597 (2026-06-16)
- 패턴: `curl -s --max-time 10 "https://open.er-api.com/v6/latest/USD" | grep -o '"KRW":[0-9.]*'`

## 미국 10년물 금리 (CNBC)
- URL: `https://www.cnbc.com/quotes/US10Y`
- User-Agent 필수
- 응답에 JSON 데이터 삽입됨 → grep으로 추출
- 패턴: `curl -sL "https://www.cnbc.com/quotes/US10Y" -H "User-Agent: Mozilla/5.0" | grep -oP '"last":"[0-9.]+%"'`
- 2026-06-16 검증: 4.441%

## KOSPI (CNBC)
- URL: `https://www.cnbc.com/quotes/.KS11`
- 패턴: `curl -sL "https://www.cnbc.com/quotes/.KS11" -H "User-Agent: Mozilla/5.0" | grep -oP '"last":"[0-9,.]+"'`
- 2026-06-16 검증: 8,726.60

## S&P 500 (CNBC JSON — 추천, Yahoo fallback)

- URL: `https://www.cnbc.com/quotes/.SPX`
- User-Agent 필수
- 2026-06-18 검증: **7,420.10** (Open 7,524.50, Change -91.25)
- Yahoo Finance 차단 시 CNBC가 안정적 fallback
- 패턴: `curl -sL "https://www.cnbc.com/quotes/.SPX" -H "User-Agent: Mozilla/5.0" | grep -oP '"last":"[0-9,.]+"'`

## S&P 500 (Yahoo Finance — 1순위, 차단 가능)
- URL: `https://query1.finance.yahoo.com/v8/finance/chart/^GSPC?interval=1d`
- User-Agent 필수. 없으면 "Too Many Requests"
- curl -o 파일 저장 후 python3로 파싱 (pipe 차단 우회)
- 2026-06-16 검증: 7,554.29
- 차단 시 → `query2.finance.yahoo.com` 또는 CNBC `.SPX`로 fallback

## WTI 유가 (CNBC JSON — 추천, Yahoo fallback)

- URL: `https://www.cnbc.com/quotes/@CL.1`
- User-Agent 필수
- 2026-06-18 검증: **$74.84** (CNBC) / $74.14 (Yahoo query2)
- 패턴: `curl -sL "https://www.cnbc.com/quotes/@CL.1" -H "User-Agent: Mozilla/5.0" | grep -oP '"last":"[0-9,.]+"'`

## WTI 유가 (Yahoo Finance)
- URL: `https://query1.finance.yahoo.com/v8/finance/chart/CL=F?interval=1d`
- User-Agent 필수
- 2026-06-16 검증: $77.38

## 금 선물 (CNBC)
- URL: `https://www.cnbc.com/quotes/@GC.1`
- COMEX Aug'26 기준
- 2026-06-16 검증: $4,366.20

## 한국주 뉴스 (Google News RSS)
- 가장 신뢰성 높은 크론용 뉴스 소스
- URL 패턴: `https://news.google.com/rss/search?q={검색어}&hl=ko&gl=KR&ceid=KR:ko`
- Rate-limit 매우 관대
- 한국어 검색 정상 작동
- 다른 소스 문제점:
  - DuckDuckGo: bot 차단 (Challenge page)
  - Naver: JavaScript 렌더링, curl 불가
  - Daum: JavaScript 렌더링
- grep 추출: `grep -oP '<title>[^<]+'`

### ⚠️ URL 인코딩 주의
bash에서 직접 한글 쿼리 사용 시 Google News 400 Bad Request 발생.
**curl 직접 호출**이 아닌 **Python urllib.parse.quote()** 로 URL 인코딩 필수.

```python
import urllib.parse, urllib.request
stock = '삼성전자'
query = urllib.parse.quote(f'{stock} 주식')
url = f'https://news.google.com/rss/search?q={query}&hl=ko&gl=KR&ceid=KR:ko'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
data = urllib.request.urlopen(req, timeout=10).read().decode('utf-8', errors='ignore')
import re
titles = re.findall(r'<title>([^<]+)', data)
for t in titles[1:6]:
    print(f'  • {t}')
```

### 종목별 검색 쿼리 (한국어)
| 종목 | 검색어 |
|:----|:------|
| 삼성전자 | `삼성전자 주식` 또는 `삼성전자 005930` |
| SK하이닉스 | `SK하이닉스 주식` |
| 삼성전기 | `삼성전기 주식` |
| 현대차 | `현대차 주식` |
| 에이피알 | `에이피알 주식` |
| HD현대일렉 | `HD현대일렉 주식` |

### Google News RSS 헤드라인 추출 패턴
- `<title>` 태그 첫 번째는 항상 "Google 뉴스" (무시)
- 실제 뉴스 제목은 `titles[1:]`

## DXY 달러 인덱스 (CNBC JSON — 검증 완료)

- URL: `https://www.cnbc.com/quotes/.DXY`
- User-Agent 필수
- 2026-06-18 최초 검증: **100.646** (Change: +0.562)
- 패턴: `curl -sL "https://www.cnbc.com/quotes/.DXY" -H "User-Agent: Mozilla/5.0" | grep -oP '"last":"[0-9.]+"'`
- background data: DXY basket = EUR 57.6%, JPY 13.6%, GBP 11.9%, CAD 9.1%, SEK 4.2%, CHF 3.6%

## Fed Funds Rate (Google News 기반 추론)

직접 API가 어려우므로 Google News FOMC 검색으로 추론.

### 검증 패턴 (2026-06-18)
```python
import urllib.parse, urllib.request, re
q = urllib.parse.quote('Fed funds rate June 2026 FOMC decision')
url = f'https://news.google.com/rss/search?q={q}&hl=en'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
data = urllib.request.urlopen(req, timeout=10).read().decode('utf-8', errors='ignore')
titles = re.findall(r'<title>([^<]+)', data)
for t in titles[1:6]:
    print(f'  • {t}')
# 출력 예: "Fed holds rates steady", "Fed leaves interest rates unchanged"
```

### CPI 데이터 (동일 방식)
```python
q = urllib.parse.quote('US CPI May 2026')
url = f'https://news.google.com/rss/search?q={q}&hl=en'
# Consumer prices rose 4.2% annually in May...
```

### Fed 의장 확인
```python
q = urllib.parse.quote('Kevin Warsh Fed chair June 2026')
# → Warsh kicks off Fed chief era...
```

### 대상 키워드
| 찾을 정보 | 검색 키워드 | 확인 패턴 |
|:---------|:-----------|:---------|
| 금리 결정 | `Fed holds rates steady` 또는 `Fed raises rates` | 타이틀에서 동결/인상/인하 확인 |
| 금리 수준 | 검색 결과 + 기존 지식 조합 | `4.25~4.50%` (동결 시 이전 유지) |
| CPI | `Consumer prices rose X% annually` | X%를 타이틀에서 직접 추출 |
| Fed 의장 | FOMC meeting 타이틀 | 의장 이름 포함 기사 확인 |
| 점도표 전망 | `dot plot` 검색 | 향후 금리 경로 예측

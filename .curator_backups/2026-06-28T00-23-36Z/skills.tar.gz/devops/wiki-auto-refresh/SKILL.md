---
name: wiki-auto-refresh
description: "매일 21:00 KST SOP Wiki 자동 갱신 — kanban 태스크 생성 → 위키 헬스 체크 → auto-fix → git push → 완료 보고"
version: 1.2.0
author: aiprofit
platforms: [linux]
metadata:
  hermes:
    tags: [wiki, auto-refresh, sop, cron, kanban, github]
    related_skills: [kanban-worker]
---

# Wiki Auto-Refresh

> **실행:** 매일 21:00 KST, cron + kanban 기반 (크론 모드에서는 kanban 생략 가능)
> **목적:** SOP Wiki(Karpathy LLM Wiki)를 자동 정리/갱신하고 GitHub에 동기화

## 실행 흐름

### 1. Kanban 태스크 생성 (크론 모드: 생략 가능)

Kanban 태스크 생성은 선택사항. 크론 모드에서 "kanban 태스크 생성/완료 불필요" 지시가 있다면 이 단계를 건너뛰고 2번으로 직행.

```python
kanban_create(
    title=f"wiki-auto-refresh-{date}",
    assignee="default",
    body=f"매일 21:00 KST wiki 정리. wiki/ 헬스 체크 + git push.",
)
```

### 2. Wiki 헬스 체크

다음을 순서대로 실행:

#### 2a. `index.md` 존재 확인 + 불일치 체크

**전제 조건**: root `index.md`가 반드시 존재해야 함. 없으면 먼저 생성.

**case A — index.md 없음:**
- `search_files(target="files", pattern="*.md", path="wiki/")`로 전체 .md 파일 수집
- 서브모듈(`logs/`, `subagents-library/` 등)은 제외
- AGENTS.md 구조 참고: `people/`, `infra/`, `analysis/`, `architecture/`, `code/`, `repos/`, `solopreneur/`, `watchlist/` 섹션
- **최상위 hub 페이지**(`hermes-trading-hub.md`)와 **하위 페이지**를 모두 포함하는 종합 카탈로그 생성
- 프론트매터 YAML에 `tags: ["wiki", "index", "navigation", "catalog"]` 포함

**case B — index.md 있음 (일반 케이스):**
- `read_file("wiki/index.md")` → 등록된 페이지 목록 파악
- `search_files(target="files", pattern="*.md", path="wiki/")` → 실제 .md 파일 목록
- index.md에 있지만 파일이 없는 페이지 → index.md에서 제거 (dead link)
- 파일은 있지만 index.md에 없는 페이지 → index.md에 추가 (적절한 섹션에)

#### 2b. Orphan 페이지 확인
- `index.md`, `AGENTS.md`, `README.md`를 제외한 모든 페이지 검사
- `search_files(pattern='\\\\[\\\\[.*\\\\]\\\\]', path='wiki/', file_glob='*.md')`로 wikilink 사용처 검색
- **추가: markdown 링크 → wikilink 변환 감지** — hub 페이지에서 `[text](path)` 형식으로 wiki 페이지를 참조하는 링크가 있는지도 확인. markdown 링크는 wikilink 참조로 인식되지 않으므로, hub 페이지에 markdown 링크가 있고 해당 페이지가 orphan이면 → 기존 링크를 `[[text]]` 형식의 wikilink로 변환 (중복 추가 금지, 기존 링크를 대체)
- wikilink로 참조되지 않은 페이지 식별 (참고: markdown 링크 `[text](path)`는 wikilink가 아니므로 제외)
- Orphan 발견 시:
  1. **hub 페이지에 markdown 링크가 있는지 먼저 확인** → 있으면 wikilink로 변환 (추가가 아닌 대체)
  2. **hub 페이지에 wikilink 추가** (markdown 링크도 없었다면)
  3. hub 페이지가 적절하지 않으면 → 해당 내용과 관련된 페이지에 `[[page-name]]` 추가
  4. 정말 고아 페이지라면 (내용이 구식/관련 페이지 없음) → index.md에서 제거 + `_archive/`로 이동

#### 2c. Stale 페이지 확인
- **확인할 날짜 필드** (우선순위 순):
  1. 프론트매터 `updated:` (YAML)
  2. 프론트매터 `created:` (생성만 되고 업데이트 없는 페이지)
  3. 인라인 `**Last updated:**` (본문 텍스트)
- 30일 이상 지난 페이지 확인
- 너무 오래된 정보면 → 업데이트 필요 플래그 (리포트에 포함)
- **날짜 정보 없는 페이지 체크**: 프론트매터/inline 날짜가 없는 페이지는 git log로 대체 확인. 리포트에 "날짜 정보 없음 (N개)" 별도 항목으로 포함. (리포트 섹션 참고)
  - 옵션: git log `--format="%ai"` 날짜를 프론트매터 `updated:` 필드로 자동 삽입 가능 — 단, 30일 미만 페이지만 (오래된 페이지는 사람이 확인 필요)

### 3. Git Push (GitHub 연동)

```bash
cd ~/.hermes/wiki
git add -A
git diff --cached --stat  # 변경사항 요약
if [ -n "$(git status --porcelain)" ]; then
  git commit -m "auto-sync $(date +%Y-%m-%d) 21:00 KST"
  git pull --rebase origin main 2>/dev/null || true
  git push origin main
fi
```

### 4. 완료 처리 및 리포트

```python
kanban_complete(
    summary=f"wiki auto-refresh 완료: N개 파일 변경, M개 orphan 처리",
    metadata={
        "files_changed": N,
        "orphans_fixed": M,
        "stale_pages": [...],
        "git_commit": "auto-sync YYYY-MM-DD 21:00 KST",
    },
)
```

Discord 리포트 형식:
```
📋 Wiki Auto-Refresh 완료 (21:00)

변경: N개 파일
Orphan 처리: M개 (wikilink 변환: X개)
Stale: K개 페이지
날짜 정보 없음: L개 페이지 (참고)

📎 GitHub: mybotagent/hermes-wiki
```

리포트 세부 항목:
- **변경**: git diff --stat 기준 파일 수
- **Orphan 처리**: wikilink 추가/변환 건수. markdown 링크→wikilink 변환 건수는 별도 표기
- **Stale**: 30일 이상 지난 페이지 목록
- **날짜 정보 없음**: 프론트매터/inline 날짜 필드가 누락된 페이지 수 (30일 미만이면 stale은 아니나 리포트에 기재)
- 변경사항이 없으면 간단히 "변경 없음"만 보고 (크론 모드) 또는 "[SILENT]" (크론 모드 지시 시)

## 주의사항
- `git push --force` 금지 — `pull --rebase` 우선
- `AGENTS.md`(schema)는 수정 금지 — 규칙 정의 파일
- `logs/`와 `subagents-library/`는 **submodule** — 이 저장소의 변경사항이 아님. `git status`에서 나타나면 무시
- **`find` 명령어로 파일 목록 조회 시** submodule 디렉토리를 반드시 제외: `find . -name '*.md' -not -path './logs/*' -not -path './subagents-library/*'`
- **`index.md` vs `INDEX.md`**: 파일명은 **소문자 `index.md`**가 정확 (AGENTS.md 스키마 규칙). `INDEX.md`(대문자)는 잘못된 명칭
- **변경사항이 없으면** `"[SILENT]"`로 응답 (크론 모드), 또는 "변경 없음"으로 간단히 완료
- **hub 페이지**는 wiki 루트의 `hermes-trading-hub.md` 또는 그에 준하는 최상위 네비게이션 페이지. orphan wikilink는 여기에 우선 추가
- **stale 날짜 포맷**: 프론트매터 `updated: YYYY-MM-DD`, `created: YYYY-MM-DD`, 본문 `**Last updated:** YYYY-MM-DD` 세 가지 포맷 모두 확인
- **빈 디렉토리**(`code/stock-analysis-toolkit/` 등)는 wiki 페이지가 아니므로 무시
- **README.md**는 프로젝트 랜딩 페이지 — AGENTS.md 구조와 중복되지 않도록 유지

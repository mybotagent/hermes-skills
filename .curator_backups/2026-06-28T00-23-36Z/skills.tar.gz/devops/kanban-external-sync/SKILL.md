---
name: kanban-external-sync
description: "Bidirectional sync between Hermes Kanban and external project management tools (Linear, Jira, GitHub Issues). Cron-driven daily reconciliation + optional webhook real-time hooks."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
prerequisites:
  env_vars: [LINEAR_API_KEY]
  commands: [hermes, sqlite3, curl]
metadata:
  hermes:
    tags: [kanban, linear, sync, integration, cron, webhook]
    related_skills: [linear, kanban-worker, kanban-orchestrator, webhook-subscriptions]
---

# Kanban ↔ External PM Tool Sync

Bidirectional sync between Hermes Kanban (SQLite) and external project management tools (primarily Linear). Runs as a daily cron job with optional real-time webhook hooks.

## Architecture

```
┌─────────────────────┐         ┌─────────────────────┐
│   Hermes Kanban     │         │   Linear (external)  │
│   (SQLite)          │         │   (GraphQL API)      │
│                     │         │                      │
│  tasks table:       │  ───►   │  issues              │
│  - id               │  sync   │  - identifier (ENG-N)│
│  - title            │  script │  - title             │
│  - body (has        │  ◄───   │  - description       │
│    linear_id marker)│         │  - state             │
│  - status           │         │  - priority          │
│  - assignee         │         │  - assignee          │
│  - priority         │         │  - labels            │
└─────────────────────┘         └─────────────────────┘

Layer 1: Daily Cron (07:00 KST)
  hermes cron rotate → script compares all records both ways

Layer 2: Linear Webhook → Hermes Webhook (real-time)
  Linear issue.create/update → POST to hermes webhook → agent run
```

## Prerequisites

- `LINEAR_API_KEY` in `~/.hermes/.env` — from Linear Settings > API > Personal API keys
- Linear **team key** (e.g., HERMES, ENG) — the team to sync Kanban tasks into
- Hermes gateway running (for webhook layer) — `hermes gateway run`

## ID Mapping

Each synced pair maintains a bidirectional ID reference stored in `~/.hermes/data/kanban_linear_mapping.json`:

```json
{
  "kanban_task_id_1": {
    "linear_issue_id": "HERMES-42",
    "linear_url": "https://linear.app/workspace/issue/HERMES-42/...",
    "kanban_updated_at": 1740000000,
    "linear_updated_at": "2026-06-25T13:00:00Z",
    "last_synced": "2026-06-25T13:00:00Z"
  }
}
```

Kanban task `body` also stores the Linear issue reference as a YAML frontmatter block:
```
---
linear_id: HERMES-42
linear_url: https://linear.app/workspace/issue/HERMES-42/...
---
Actual task description...
```

## Status Mapping

| Kanban Status | Linear State Type |
|---------------|-------------------|
| `todo`        | `backlog` / `triage` |
| `ready`       | `unstarted` |
| `in_progress` | `started` |
| `done`        | `completed` |
| `blocked`     | `triage` (or custom blocked state) |
| `cancelled`   | `canceled` |

Field sync rules (Kanban → Linear unless noted):
- **title** → `title` (bidirectional, latest updatedAt wins)
- **body** → `description` (Kanban → Linear only)
- **status** → state (bidirectional mapped via table above)
- **priority** → priority (bidirectional: 0=urgent...4=low in both systems)
- **assignee** → assignee (Kanban → Linear only — Linear has richer user model)

## Sync Script

Located at `~/.hermes/scripts/kanban_linear_sync.py`. Called by cron.

Logic flow:
1. Load mapping file
2. Query all Linear issues for the configured team via `linear_api.py list-issues --team KEY`
3. Query all Kanban tasks via `hermes kanban list --json`
4. **Kanban→Linear**: For kanban tasks with a linear_id not found in Linear → create issue, update mapping
5. **Linear→Kanban**: For Linear issues without a kanban task → create kanban task, update mapping
6. **Status sync**: For matched pairs, compare status/assignee/priority and update whichever side is stale
7. Save updated mapping
8. Print summary report

**Kanban task creation for new Linear issues:**
```bash
hermes kanban create "issue title" \
  --assignee default \
  --priority N \
  --body "---\nlinear_id: ID\nlinear_url: URL\n---\n\ndescription"
```

**Kanban status update via SQLite** (since hermes kanban has no direct status-set, use `hermes kanban complete` or block):
```bash
hermes kanban complete TASK_ID --summary "synced from Linear"
```

## Cron Job Setup

Register daily sync at 07:00 KST (= UTC 22:00 previous day):
```bash
hermes cron create "kanban-linear-sync" \
  --schedule "0 22 * * *" \
  --script ~/.hermes/scripts/kanban_linear_sync.py \
  --name "Kanban ↔ Linear daily sync"
```

Since this uses no_agent pattern (output = report), use no_agent=True if the script produces its own summary.

## Webhook Layer (Optional, for Real-Time Sync)

### Linear → Kanban (Linear webhook → Hermes webhook)
1. Enable Hermes webhook: `hermes gateway setup` → enable webhooks on port 8644
2. Subscribe to Linear events:
```bash
hermes webhook subscribe linear-sync \
  --events "issue.create,issue.update" \
  --prompt "Linear issue {action}d: {data.title} ({data.identifier})\n\nCheck if this issue has a matching kanban task and sync if needed."
  --skills "kanban-external-sync" \
  --deliver origin
```
3. Configure Linear webhook: Settings → API → Webhooks → Add endpoint to Hermes webhook URL

### Kanban → Linear (Detect kanban changes)
Kanban is local SQLite with no outgoing webhooks. Use cron (Layer 1) for this direction.

## Pitfalls

- **Sync loops**: Always check `kanban_updated_at` vs `linear_updated_at` before writing. Skip update if the other side already has the latest change (avoid A→B→A→B infinite loop).
- **LINEAR_API_KEY missing**: The sync script exits with a clear error. Add to `~/.hermes/.env`.
- **Team UUID**: The script resolves team key to UUID on each run. If the team key changes, update the config.
- **Rate limits**: Linear allows 5,000 requests/hr. The daily sync is well within this. Webhook events are individual calls — safe unless hundreds fire per minute.
- **Kanban task with no matching profile**: New tasks created from Linear issues use `--assignee default`. Change if a specific kanban profile should handle them.
- **Mapping file corruption**: If `kanban_linear_mapping.json` is deleted or corrupted, the next sync run re-discovers all pairs by matching titles + body markers. Data is not lost, but takes one extra cycle to stabilize.

## Related

- [linear](../productivity/linear/README.md) — Linear API skill that this sync uses
- [kanban-worker](../devops/kanban-worker/README.md) — Kanban worker lifecycle
- [webhook-subscriptions](../devops/webhook-subscriptions/README.md) — Webhook setup for real-time sync layer

---
name: macro-strategy-report
description: 글로벌 매크로 전략 리포트 — Causal Analysis 기반, Source Hierarchy, Counter-factual, Priority Matrix
---

# 🌍 Macro Strategy Report (매크로 전략 리포트)

> **핵심**: 감정 배제, 인과관계(Causality) 중심, 데이터 기반. 투자 영향도 순(Priority Matrix)으로 정리.
> 매일 18:30 KST cron job (job_id: e69746446a65). 미국 증시 브리핑(18:00) 이후 추가 리포트.

## 🧠 사용자 선호 (반드시 준수)

1. **투자 영향도 순 정리**: 가장 투자에 큰 영향을 미치는 이슈부터 Priority 1 → 5 순으로 배열. 맨 아래 Priority Matrix 요약 표로 마감.

2. **데이터의 최신성과 정확성 최우선**: 24~48시간 내 데이터만 사용. 출처를 꼬리표로 명시 (예: [Reuters 6/5], [ECB 6/5]). 가상 데이터 절대 금지 — 실제 검색 결과가 없으면 리포트 생략.

3. **BUY/CAUTION 신호 명확히 구분**: Orbit T0/T1 괴리율 + FPER 분석 기반으로 '매수 기회'인지 '경계 구간'인지 결론 제시 (Section 6: Investment Signals). FPER이 극단적으로 낮은(5~10) 종목은 하방 레버리지 경고 필수. **T0/T1 갭 해석 프레임워크**로 판단:
   - **메모리 트랩** (T0 -56~-71% + T1 +59~+94%): FPER 5~10, EPS 폭발 선반영 → 🔴 경계
   - **AI Core 적정** (T0 -12~-29% + T1 +18~+70%): PE/FPE 1.5~2.5 건강 → 🟢 매수/관심
   - **Non-AI 정체** (T0 ±20% + T1 ±15%): 변동성 낮음 → 🟢 안전주
   - **장비주 고PER** (T0 -55~-62% + T1 -32%): PER 60~75 높은 멀티플 → 🔴 멀티플 부담

4. **추정 불가 영역은 '데이터 미비'로 명시**: 억지 결론 금지. Counter-factual 시나리오에도 확률(%)은 데이터 기반으로만 제시. **'데이터 미비'는 리포트에 명시적으로 표기하고 추정을 유보할 것.**

5. **크론잡 등록 시 승인 절차 필수**: 크론 등록/수정은 무조건 사용자에게 먼저 확인 받을 것. 사용자 동의 없이 등록 금지. 매일(평일 제한 없음)이 기본 (`30 18 * * *`). 평일 전용이면 그 이유도 함께 설명.

6. **기존 크론잡은 절대 수정 금지, 추가만 가능**: 이 리포트는 기존 18:00 미국 브리핑 이후 __추가__로 동작. 기존 작업 건드리지 말 것.

7. **출처 명시 규칙**: 모든 결론에 출처를 꼬리표로 붙일 것. 1순위(공식 기관) > 2순위(싱크탱크) > 3순위(경제 외신). 출처 없는 주장은 리포트에서 제외.

---

## 📋 리포트 구조 (반드시 이 형식)

### 1. Executive Summary
- **Key Driver 1가지**와 그 파급력 요약
- 세 가지 미만의 핵심 축(Axis)으로 구조화

### 2. Current Macro State
표 형식: 지표명 | 수치 | 방향성(⬆️➡️⬇️) | 해석 | 출처

### 3. Causal Linkage
[원인 → 전파 경로 → 결과] 메커니즘으로 주제별 서술
- 각 주제마다 ````로 감싼 인과 체인 다이어그램
- `[1차 결과]` → `[2차 결과]` → `[3차 결과]` 단계로 전파
- 포트폴리오 종목별 Direct/Indirect Impact 함께 서술
- 상관관계(Correlation)와 인과관계(Causality) 명확히 구분

**포트폴리오 25종목**: NVDA, AVGO, LITE, MU, LRCX, STX, SNDK, TSM, AMD, INTC, CLS, TER, MRVL, HPE, GOOGL, AAPL, MSFT, DELL, LLY + 삼성전자, SK하이닉스, 삼성전기, 현대차, HD현대일렉, 에이피알

### 4. Counter-factual Analysis
2~3개 반대 시나리오. 각 시나리오:
| 항목 | 내용 |
|:----|:-----|
| **Trigger** | 어떤 조건에서 발생? |
| **3개월 내 전파 경로** | 시장·환율·종목별 연쇄 |
| **포트폴리오 영향** | 종목별 구체적 수치/방향 |
| **확률** | % (데이터 기반) |
| **데이터 미비** | 있다면 명시 |

### 5. Structural Implications (6~12개월)
- ✅ **예측 가능한 변화** — 데이터 충분
- ⚠️ **데이터 미비로 추정 불가** — 명시 후 추정 유보

### 6. Priority Matrix (맨 아래)
| 순위 | 이슈 | 영향 종목 | 방향성(🟢/🟡/🔴) | 신뢰도(高/中) |
|:---:|:----|:---------|:--------------:|:-----------:|

---

## 🔍 Source Hierarchy (Hard Rule)

| 순위 | 출처 유형 | 예시 | 비고 |
|:---:|:---------|:----|:-----|
| **1순위** | 공식 기관 보고서/정책 | IMF, BIS, World Bank, Fed, ECB, BOJ, BIS Federal Register | 필수 우선 확인 |
| **2순위** | 공식 싱크탱크 | Council on Foreign Relations, CSIS, Peterson Institute | 1순위 불가 시 사용 |
| **3순위** | 신뢰도 높은 경제 외신 | Reuters, Bloomberg, CNBC, WSJ, FT | 데이터 요약 기사만 |
| **❌ 배제** | 추측/커뮤니티/차트 | Reddit, X/Twitter, Seeking Alpha 코멘트, 기술적 차트 분석 | 절대 금지 |

## 🌐 수집 대상 (투자 영향도 순)

1. **(1순위) 반도체·AI**: BIS 수출통제, HBM/DDR5 가격 동향, AI CapEx 뉴스, 주요 반도체 기업 발표
2. **(2순위) 통화정책**: Fed·ECB·BOJ 연설/회의록, 주요국 금리 변화, CPI/고용
3. **(3순위) 지정학**: 미중 갈등, 대만, 관세, 소재(Ga/Ge) 수출통제
4. **(4순위) 매크로 지표**: ISM, CPI, 고용, 금리/환율 움직임

## 📡 데이터 수집 방법 (중요)

> ⚠️ `web_search` 도구가 **항상 존재하는 것은 아니다** — 특히 cron 잡(사용자 없는 자동 실행)에서는 `web_search`가 툴 목록에 없을 수 있다. 반드시 아래 **Fallback 방법**을 먼저 숙지하고 준비할 것.

### 방법 A (Preferred): 개별 툴로 직접 검색 (가능할 때)
- `web_search` 또는 `browser_navigate` + `browser_snapshot` 사용 가능 시 각 카테고리별 병렬 검색
- 신뢰도 높은 출처(Reuters, Bloomberg, CNBC, WSJ)의 최근 기사 우선

### 방법 B (Fallback - cron 환경): Google News RSS → curl + grep
> `web_search` 도구가 없거나 `delegate_task`로 검색 결과가 안 들어올 때 사용.

Google News RSS는 브라우저 없이 curl로 직접 headlines 수집 가능:
```bash
# 검색어를 URL 인코딩해서 news.google.com/rss/search?q=... 로 호출
curl -s "https://news.google.com/rss/search?q=KEYWORD&hl=en-US&gl=US&ceid=US:en" \
  | grep -oP '<title>.*?</title>' | head -20
```

**실행 절차:**
1. 아래 4개 카테고리를 **terminal() 4병렬**로 동시 검색 (timeout=15)
2. 각 결과의 `<title>` 태그에서 기사 제목 추출
3. 흥미로운 기사 제목이 보이면 추가 검색으로 상세 내용 확인
4. 반드시 출처와 날짜가 명시된 정보만 리포트에 포함

**Pitfall: `delegate_task`로 뉴스 수집 금지**
- `delegate_task`로 보낸 서브 에이전트는 검색을 설명만 하고 실제로 실행하지 않는 경우가 있음 (tool_trace = [])
- **직접 `terminal()`로 curl 검색**해야 실제 데이터가 확보됨

**참고**: 실제 동작하는 검색 URL 패턴은 `references/rss-feed-patterns.md` 참조

## 🎯 투자 판단 프레임워크 (Orbit v2 연동)

`fair-value-portfolio` 스킬의 T0/T1 괴리율 + FPER 데이터를 매크로 리포트의 투자 판단에 연계:

### 1) T0 vs T1 갭 분석 — 핵심 해석 도구

**가장 중요한 건 T0(현재 적정가)와 T1(1년 후 적정가)의 괴리율 차이**:

| 패턴 | T0 괴리율 | T1 괴리율 | 해석 | 판단 |
|:----|:--------:|:--------:|:-----|:----:|
| **메모리 트랩** | -56% ~ -71% | +59% ~ +94% | 현재가는 적정가의 2~3배 비쌈. T1은 FPER 5~10 기반 EPS 폭발 가정. 피크 EPS는 지속되지 않음. | 🔴 **하방 레버리지 > 상방**. EPS +10% 미스 = 주가 -20~30% |
| **AI Core 적정** | -12% ~ -29% | +18% ~ +70% | T0도 적정가 근접, T1 구조적 성장 반영. PE/FPE 1.5~2.5로 건강함. | 🟢 **매수/관심**. Analyst-Model 갭 좁음 |
| **Non-AI 정체** | -2% ~ -21% | -8% ~ +13% | T0/T1 모두 ±20% 내. 고평가도 저평가도 아님. | 🟢 **안전자산**. 방어적 포지션 |
| **장비주 고PER** | -55% ~ -62% | -32% | PER 60~75로 높지만 FPER도 높아 개선 중. T1만 봐도 아직 비쌈. | 🔴 **멀티플 부담**. 사이클 후행성 리스크 |

**핵심 질문**: "지금 사면 싼 건가?"
→ T1 기준으로는 싸다. T0 기준으로는 비쌀 수 있다.
→ FPER이 낮을수록(5~10) EPS 폭발을 가격에 넣은 것. **피크 EPS는 지속되지 않는다**는 원칙铭记.

### 2) Analyst-Model 갭 해석

| 갭 | 의미 | 신뢰도 |
|:--:|:----|:-----:|
| Analyst ≈ Model (±10%) | 두 모델 일치 = fair value 신뢰도 높음 | 🟢 HIGH |
| Model > Analyst (+15~50%) | Model이 낙관적. 성장성 높게 평가 | 🟡 Model 검증 필요 |
| Model < Analyst (-10~25%) | Model이 보수적. 과대낙관 경계 | 🟢 보수적 접근 타당 |

### 3) 종합 판단 기준

| 조건 | 판단 | 설명 |
|:----|:----:|:-----|
| T1 ≥ +20% + FPER ≥ 12 + T0 ≥ -30% | 🟢 **매수** | 성장주, 적정 범위 내. Analyst-Model 일치 여부 확인 |
| T1 ≥ +50% + FPER < 12 + T0 ≤ -50% | 🔴 **경계 (FPER 트랩)** | EPS 폭발 선반영. 하방 레버리지 2~3배 |
| T1 ≥ +50% + FPER < 12 + Analyst ≈ Model | 🟡 **조건부 관심** | Analyst도 동의=일부 정당화. BUT 사이클 리스크 인지 |
| T1 < 0% ~ +15% + T0 ±20% 내 | 🟢 **안전주/방어** | 변동성 낮음. 매수보다 보유에 적합 |
| T1 ≥ +100% + 마진 10% 미만 | 🟡 **투기적** | HPE 유형. 소액 배팅 가능 but 포트폴리오 핵심 부적합 |

## ⏰ 실행 정보

- **cron job**: e69746446a65 (매일 18:30 KST)
- **선행**: 🇺🇸 미국 증시 브리핑 (18:00, b5bbf669cd51)
- **데이터 수집 방식**: Google News RSS (curl + grep) — `web_search` 도구가 없다면 이 방법 사용. `references/rss-feed-patterns.md` 참조.
- **SILENT 규칙**: 수집 결과가 없거나 의미 있는 변화가 없으면 `[SILENT]` 응답 (배송 차단)
- **후행**: 🧠 LangGraph 파이프라인 (18:35, 62e57f, 평일) — 이 리포트의 내용을 읽어서 종목별 분석에 반영

## 📦 JSON 저장 형식 (Pipeline 연동 — macro_context.json)

리포트를 Discord에 출력하기 전에 **반드시** 아래 구조로 `/home/ubuntu/trading-agents-nuri/data/macro_context.json`에 저장 (크론 작업 시 사용자 명시 경로):

```json
{
  "timestamp": "2026-06-06T18:30:00+09:00",
  "date": "2026-06-06",
  "macro_report_summary": "리포트 전문 (3000자 이상, Executive Summary ~ Priority Matrix 전체)",
  "key_macro_data": {
    "fed_rate": "4.25~4.50%",
    "ecb_rate": "2.00%",
    "boj_rate": "0.50%",
    "dxy": "104.2",
    "usdkrw": "1320",
    "us10y": "4.45%",
    "wti": "68.5",
    "cpi_yoy": "2.7%",
    "nonfarm": "+172K"
  },
  "market_interpretation": {
    "key_driver": "핵심 동인 1가지 요약",
    "market_sentiment": "risk-off / risk-on / mixed",
    "regime": "Goldilocks / Slowdown / Overheat / Stagflation / Severe_Inflation / Deflation",
    "impact_analysis": "포트폴리오 종목별 인과관계 해석"
  },
  "news_items": [
    {"title": "뉴스 제목", "source": "Reuters/Bloomberg/CNBC", "impact": "high/medium/low", "summary": "요약", "affected_tickers": ["NVDA", "MU"]}
  ]
}
```

**핵심 규칙:**
- `macro_report_summary` 필드에 **시장 해석 포함 전체 리포트** 저장 (단순 수치 나열 금지)
- `market_interpretation` 필드에 **투자 관점의 인과 해석** 저장
- `key_macro_data`에 **실제 수치만** 저장
- **유효한 JSON만 저장**할 것 (`cat macro_context.json` 검증)
- `collect_macro_context.py`(Phase 0.5)가 이 파일을 읽어서 Finnhub 뉴스 추가 → 파이프라인에 전달

**Flow**: `18:30 크론 → macro_context.json 저장 → collect_macro_context.py (Finnhub 뉴스 추가) → LangGraph Phase 2 → 종목별 분석 (시장 해석 인용)`

## 🔗 관련 스킬

- **`fair-value-portfolio`**: Orbit v2 T0/T1 적정가 데이터 제공
- **`stock-rating-system`**: S+~F 정성 평가

## 📎 참고 파일

- `references/rss-feed-patterns.md` ✅ — Google News RSS 검색 URL 패턴 (cron 환경 데이터 수집용)
- `references/counter-factual-templates.md` — 향후 추가 예정 (반대 시나리오 템플릿)
- `references/source-hierarchy-checklist.md` — 향후 추가 예정 (출처 검증 체크리스트)

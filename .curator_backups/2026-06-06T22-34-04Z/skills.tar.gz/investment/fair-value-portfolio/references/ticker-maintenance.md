# Ticker Maintenance Guide (관심종목 추가/제거)

> 5 files to touch when adding/removing a ticker from the watchlist.

## 1. `fair_value_v3.py` (STOCKS 리스트)

**위치**: `/home/ubuntu/.hermes/scripts/fair_value_v3.py` — lines 15-25

```python
STOCKS = [
    ('NVDA', '엔비디아', 'US'), ('MU', '마이크론', 'US'),
    # ... add or remove tuples: (ticker, name, market)
]
```

- US ticker: plain symbol like `'NVDA'`
- KR ticker: suffix with `.KS` (KOSPI) or `.KQ` (KOSDAQ), e.g. `'005930.KS'`
- INTC is excluded due to insufficient yfinance data — adding it will produce a warning, not an error
- If the stock has a custom sector override, also update `TICKER_SECTOR` dict (line ~47)

## 2. `analyst_target_collector.py` (KR_TICKERS)

**위치**: `/home/ubuntu/.hermes/scripts/analyst_target_collector.py` — lines 19-26

```python
KR_TICKERS = {
    '005930.KS': '삼성전자',
    # ...
}
```

- Only needed for KR stocks (US stocks use `upgrades_downgrades` automatically)
- Add/remove KR ticker → code pairs here
- If the stock has a known target price, also update `KR_KNOWN_TARGETS` dict

## 3. Wiki: `index.md` (📈 Watchlist)

**위치**: `~/.hermes/thread-wikis/hermes-wiki-portfolio/index.md`

- Update the US and KR bullet lists
- Update the count (21개, 15+6, etc.)

## 4. Wiki: `METHODOLOGY.md` (섹터 테이블)

**위치**: `~/.hermes/thread-wikis/hermes-wiki-portfolio/METHODOLOGY.md`

- Update the sector→ticker mapping table (around line 31-49)
- If a sector becomes empty after removal, that's fine — keep the row, it may be reused
- When adding a new sector (e.g. MLCC), add a row with the base PER value

## 5. SKILL.md (fair-value-portfolio 관심 종목 + 코드 예제)

**위치**: `~/.hermes/skills/investment/fair-value-portfolio/SKILL.md`

- Update the "## 관심 종목" human-readable list
- Update code examples in Phase 5 methodology section (SECTOR_BASE, TICKER_SECTOR)
- Update accuracy table if needed
- New sectors added here need both SECTOR_BASE entry and TICKER_SECTOR mapping

## Sector naming convention

When adding a new ticker with a unique business type that yfinance misclassifies:
1. Add sector to `SECTOR_BASE` with a reasonable base PER (reference: existing sectors)
2. Add ticker → sector mapping to `TICKER_SECTOR`
3. Sector names should be English, descriptive (e.g. 'MLCC' not '적층세라믹')
4. Base PER values: high-growth/tech 22-28, equipment/components 18-22, cyclical/industrial 10-15

## Sector classification first, removal last

The user's preferred workflow when a stock scores poorly (🔴 T1 < -30%):
1. First check if the **sector classification** is correct — yfinance often misclassifies
2. Correct the sector in TICKER_SECTOR (e.g. LITE → Optical Communications not Technology)
3. Add a new sector to SECTOR_BASE if needed (e.g. MLCC base 18 for 삼성전기)
4. Re-run the model — poor scores often improve with correct sector base
5. Only remove as a last resort if the stock is truly un-analyzable (e.g. INTC: yfinance data insufficient)

The user re-added all previously removed stocks after sector corrections — sector accuracy was the root cause, not model limitation.

## Verification after change

```bash
cd /home/ubuntu/.hermes
./hermes-agent/venv/bin/python3 scripts/fair_value_v3.py
```

- Check that all tickers produce valid data
- Check sector assignment in the output (적정PER column reflects the sector base)
- Push wiki changes: `cd ~/.hermes/thread-wikis/hermes-wiki-portfolio && git add -A && git commit -m "..." && git push`

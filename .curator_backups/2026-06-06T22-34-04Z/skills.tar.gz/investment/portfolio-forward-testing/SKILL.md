---
name: portfolio-forward-testing
description: 포트워드 테스팅 — LangGraph BUY/SELL/HOLD 결정 추적, Gap+Moat 기반 포트폴리오 비중, Macro Regime 기반 현금 비중, 월간 검증 피드백 루프
---

# Portfolio Forward Testing Framework

**관련 스킬**: `fair-value-portfolio` (밸류에이션 데이터 + LangGraph 결정), `stock-rating-system` (Moat 점수)

## 개요
LangGraph 파이프라인의 BUY/SELL/HOLD 결정을 실제 시장 데이터와 비교하여 검증. 포트폴리오 비중은 T1-gap(괴리율) × Moat(해자)로 산정, 현금 비중은 Macro Regime + Alpha-Flip + 뉴스 심각성(LLM 판단). 월 30,000원 예산 내에서 운영.

**통합 레포**: `~/trade-pipeline/` → `github.com/mybotagent/trade-pipeline` (langgraph/ 서브디렉토리)
**기타 모든 구 trading-agents-nuri 레포는 GitHub ARCHIVED + 로컬 삭제 완료.**

## Trigger 조건
- 파이프라인 실행 후 (18:35 cron)
- 매월 1일 (월간 검증)
- 사용자가 "포워드 테스팅", "포트폴리오 기록", "검증", "피드백" 언급 시

## 실행 순서

### 1. 결정 검증 — Decision Validator (매일, 파이프라인 실행 시 자동)

```bash
cd ~/trade-pipeline && python3 langgraph/src/agents/decision_validator.py
```

`decision_validator.py`가 `logs/decisions/`의 모든 JSON 파일을 읽어서:
- **US ticker**: yfinance로 현재가 조회
- **KR ticker (.KS)**: 네이버 API(`api.finance.naver.com/service/itemSummary.nhn`)로 현재가 조회
- 결정 시점 가격 vs 현재가 비교 → 수익률 측정
- 종목별 한글명→yfinance ticker 매핑 (`TICKER_MAP`: 삼성전자→005930.KS, SK하이닉스→000660.KS, 샌디스크→SNDK 등)
- `logs/validation/YYYY-MM-DD.json` — 정형 데이터 저장
- `logs/validation/YYYY-MM-DD.md` — 리포트 저장 (중복 제거, 종목별 최신 결정만 표시)

**Nota bene**: 모든 결정 데이터가 같은 날짜면 수익률은 0.00%로 표시됨 (정상). 최소 1영업일 이상 간격이 있어야 의미 있는 수익률 계산 가능.

### 2. 포트폴리오 비중 산식 (2026-06-08 v2 — t1_gap × moat 곱셈식)

```
보정_gap = max(0, t1_gap)              # T1 괴리율 (순수 Model T1 적정가 기준)
moat_점수 = LLM 추정 (1~10)              # 해자 요소 기반 (특허/독점/네트워크효과/전환비용/브랜드/규제장벽)
가중값 = 보정_gap × moat_점수
기본_비중 = (가중값 / Σ가중값_all) × (1 - cash_ratio)
비중 = clamp(기본_비중, 2%, 15%)        # 최소 2%, 최대 15% (무조건 적용)
```

**변경 이력**:
- 2026-06-07: `mid_gap` 기반 (midpoint_gap = T1+Target 평균), `Gap_Score × 0.6 + Moat_Score × 0.4` 가중합
- 2026-06-08 v1: `t1_gap 단독` (Moat 금지)
- **2026-06-08 v2: `t1_gap × moat_score` 곱셈식** (gap+moat 두 요소만, PER/성장성/현금흐름 반영 금지)

### 3. 현금 비중 (Macro Regime + Alpha-Flip + 뉴스 심각성)

| Regime | Base | +AlphaBearish(+5%p) | +AlphaBullish(-5%p) |
|:------:|:----:|:-------------------:|:------------------:|
| Goldilocks | 5% | 10% | 0% |
| Overheat | 15% | 20% | 10% |
| Slowdown | 25% | 30% | 20% |
| Stagflation | 40% | 45% | 35% |
| Severe_Inflation | 30% | 35% | 25% |
| Deflation | 10% | 15% | 5% |

**추가 조정 (2026-06-08 v3)**: 극단적 이벤트 발생 시 LLM이 +10~20%p 추가 가능
- Broadcom 쇼크($1.3조 증발), 전쟁(유가 급등), 원화 급락 등
- 최대 현금 50%까지 가능
- `cash_reason` 필드에 구체적 근거 명시 (예: "Slowdown 25% + Bearish 5% + Broadcom쇼크 10% = 40%")

Regime 출처: 18:30 매크로 리포트의 `market_interpretation.regime`
Alpha-Flip 출처: `market_interpretation.alpha_flip_signal` (없으면 Neutral)

### 4. 결정 평가 기준

| Pipeline 판단 | 실제 결과 | Score |
|:-------------:|:---------:|:-----:|
| BUY | 주가 상승 | +2 |
| BUY | 주가 하락 | -1 |
| SELL | 주가 하락 | +2 |
| SELL | 주가 상승 | -1 |
| HOLD | ±5% 유지 | +1 |
| HOLD | >5% 상승 | 0 |
| HOLD | >5% 하락 | +1 |

**월간 Accuracy = ΣScore / ΣMaxScore × 100**

### 5. 월간 검증 — Monthly Performance Review (매월 1일 08:10 KST)

```bash
cd ~/trade-pipeline && python3 langgraph/src/monthly_performance_review.py
```

출력 항목:
1. Decision Summary — BUY/SELL/HOLD 건수, 신뢰도 분포
2. Portfolio — 관측된 Regime 분포, 평균 현금비중
3. **Decisions Validated** — `logs/validation/` 에서 과거 결정 수익률 + 정확도 가져옴
4. Weight Distribution — 상위 5개 종목 비중
5. Cost Summary — 월 비용 (예산 30,000원 대비 %)
6. Improvement Suggestions — 데이터 기반 개선 제안 (DeepSeek LLM 분석)

**결정 검증 통합 (validation_data → prompt → LLM):**
- `collect_validation()` 함수로 `logs/validation/` 최신 JSON 읽기
- LLM 프롬프트에 검증 결과 섹션 자동 추가 (정확도, 수익률, 종목별 현황)
- 리포트 헤더에 검증 요약 표시

### 6. 예산 관리
- **월 한도**: 30,000원
- **초과 방지**: 누적 27,000원(90%) 초과 시 경고
- **위험**: 30,000원 도달 시 일부 분석 skip

## ⚠️ 함정 및 주의사항

### 0. 🔴 크론 테스트: `cronjob action='run'` 사용 금지 — 직접 `terminal()` 호출

크론 테스트 시 `cronjob(action='run', job_id=...)`은 **bg-review 세션**에서 실행되며,  
bg-review 세션은 `terminal`, `patch`, `web_search` 등 실제 실행 툴이 **모두 차단**됨.

```python
# ❌ 이렇게 하면 실행 안 됨 (bg-review에서 터미널 차단)
cronjob(action='run', job_id='6297df83d4f3')

# ✅ 이렇게 직접 terminal()로 순차 실행해야 함
terminal('cd ~/trade-pipeline && python3 langgraph/src/analyst_target_collector.py')
terminal('cd ~/trade-pipeline && python3 langgraph/src/fair_value.py')
terminal('cd ~/trade-pipeline && python3 langgraph/pipeline.py')
```

**중요**: 데이터 파일 체인(`data/analyst_stdout.txt` → `data/fair_value_stdout.txt` → `data/daily_snapshot.json` → ...)이 있으므로 **절대 동시 실행 금지**, 반드시 순차 실행.

### 1. 🟡 결정 평가는 최소 1영업일 간격 필요
- 같은 날짜의 결정 데이터는 수익률 0.00% (변화 없음)
- 의미 있는 평가는 최소 하루 이상 경과 후 가능
- `decision_validator.py` 실행 시점과 결정 시점 간 차이가 중요

### 2. 🟡 한국 주식 통화 표시 주의
- `decision_validator.py`의 `TICKER_MAP`은 yfinance 심볼 사용 (.KS)
- `KRW_DISPLAY_NAMES`에 한글명 등록 시 `₩` 표시 (삼성전자, SK하이닉스 등)
- yfinance가 반환하는 가격은 원화지만 `$`로 표시될 수 있음 (데이터 구조 문제)
- `decision_validator.py`의 `format_report()`에서 한국 종목은 `currency = "KRW"`로 오버라이드

### 3. 🟡 Naver API vs yfinance: 데이터 소스 라우팅
- **KR ticker 목표주가**: `analyst_target_collector.py`의 `get_kr_naver_consensus(code)` 사용
  - `finance.naver.com/item/coinfo.naver?code=005930` → coinfo 페이지 스크래핑
  - euc-kr 인코딩, Referer 헤더 필요
  - 1순위: 너구리 제공 target, 2순위: 네이버 컨센서스
- **US ticker 목표주가**: yfinance `upgrades_downgrades` 사용 (30일 window)
- **KR ticker 현재가** (validator): yfinance `.KS` suffix 사용 (005930.KS)
- **US ticker 현재가** (validator): yfinance 일반 ticker 사용

### 4. ⚠️ 데이터 누적 기간
- 최소 2주(14일) 이상 누적 후 월간 검증 의미 있음
- 초기 월간 리포트는 "데이터 부족" 상태로 출력

## Pitfalls
- `logs/validation/` 디렉토리는 06:00 cleanup에서 제외 (히스토리 보존)
- `logs/validation/` JSON 파일이 점점 커지면 분기별 아카이브 고려
- `TICKER_MAP`에 새 종목 추가 시 yfinance 심볼 확인 필수 (특히 한국주 .KS/.KQ)
- 예산 초과 시 `decision_validator.py`는 yfinance만 사용하므로 API 비용 없음 (무료)

## 📎 참고 파일
- `references/forward-testing-wiki.md` — Wiki 문서 (전체 프레임워크)
- `templates/` — (향후) 포트폴리오 리포트 템플릿

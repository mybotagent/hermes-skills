# CSV Format Specification

## 헤더 (8개 필드)
```
date,time,meds,exercise,sleep,mood,physical,diet
```

## 정확한 필드 수 = 8 (trailing comma 금지)

### 아침 (sleep만 기록) — 8개 필드
```
2026-06-13,06:11,,,yes,,,
```
- date, time, (meds=empty), (exercise=empty), **sleep**, (mood=empty), (physical=empty), (diet=empty)
- `,,,yes,,,` = 7 commas = 8 fields ✓
- ❌ `,,,,yes,,,` = 8 commas = 9 fields → sleep값이 physical 컬럼으로 shift됨

### 저녁 (sleep 제외 5개) — 8개 필드
```
2026-06-10,21:05,yes,yes,,good,good,yes
```
- date, time, **meds**, **exercise**, (sleep=empty), **mood**, **physical**, **diet**

## Catch-up (아침에 저녁 문항 기록)
```
2026-06-12,06:27,yes,no,,bad,bad,yes
```
- 어제 날짜로 기록, time은 현재 시각
- sleep 비움

## bash로 append 시 주의
```bash
# 아침 (sleep만)
echo '2026-06-13,06:11,,,yes,,,' >> ~/.hermes/survey/log.csv

# 저녁 (5문항)
echo '2026-06-10,21:05,yes,yes,,neutral,neutral,yes' >> ~/.hermes/survey/log.csv
```

## Python DictReader로 읽을 때
```python
reader = csv.DictReader(StringIO(raw))
for r in reader:
    val = r['sleep']  # 정확한 컬럼명
```

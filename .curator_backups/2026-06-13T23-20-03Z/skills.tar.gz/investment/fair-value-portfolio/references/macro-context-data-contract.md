# Macro Context Data Contract

## Producer: 18:00 통합 크론 (Step 2: LLM 매크로 리포트)
### Output: `data/macro_context.json`

```json
{
  "macro_report_summary": "string (리포트 전문)",
  "key_macro_data": {
    "fed_rate": "string",
    "dxy": "string",
    "usdkrw": "string",
    "us10y": "string",
    "wti": "string",
    "cpi_yoy": "string",
    "nonfarm": "string"
  },
  "market_interpretation": {
    "key_driver": "string",
    "market_sentiment": "risk-on|risk-off|neutral",
    "impact_analysis": "string",
    "regime": "Goldilocks|Overheat|Slowdown|Stagflation"
  },
  "news_items": [
    {
      "title": "string",
      "source": "string",
      "impact": "high|medium|low",
      "summary": "string",
      "affected_tickers": ["string"]
    }
  ]
}
```

## Consumers

### 1. pipeline.py Phase 0.5
```python
mc.get("key_macro_data", {})       # korrect
mc.get("market_interpretation", {})  # korrect
mc.get("news_items", [])            # korrect
```

### 2. context.py (`src/agents/context.py`)
```python
mc = state["macro_context"]
mk = mc.get("key_macro_data", {})     # ← was: mc.get("market", {})  (BUG!)
mi = mc.get("market_interpretation", {})
# key_driver: mi.get("key_driver", "N/A")
# dxy:        mk.get("dxy", "N/A")
# usdkrw:     mk.get("usdkrw", "N/A")
# tnx:        mk.get("us10y", "N/A")  # was: mk.get("tnx") - wrong key name
# events:     news_items titles with medium/high impact
# risks:      news_items titles with high impact only
```

### 3. risk.py (`src/agents/risk.py`)
```python
mk = mc.get("key_macro_data", {})     # ← same bug fixed
# vix:    mk.get("vix", "N/A")        # vix not collected by LLM cron - N/A
# dxy:    mk.get("dxy", "N/A")
# tnx:    mk.get("us10y", "N/A")
# usdkrw: mk.get("usdkrw", "N/A")
```

### 4. report.py (`src/report.py`)
```python
mk = mc.get("key_macro_data", {})     # ← same bug fixed
mi = mc.get("market_interpretation", {})
# metrics: fed_rate, us10y, dxy, wti, usdkrw (was: vix, tnx, dxy, wti, gold, usdkrw)
# key_driver: mi.get("key_driver", "")
# regime: mi.get("regime", "")
# events: news_items titles with medium/high impact
# risks:  news_items titles with high impact only
```

### 5. portfolio_allocation.py (`src/agents/portfolio_allocation.py`) ✅
```python
# CORRECT - reads the right keys:
interp = macro_ctx.get("market_interpretation", {})
key_data = macro_ctx.get("key_macro_data", {})
report = macro_ctx.get("macro_report_summary", "")
```

## Common Bugs (실제 발생 사례, 2026-06-07)

| 버그 | 발생 파일 | 원인 | 결과 |
|:----|:---------|:-----|:-----|
| `mc.get("market", {})` | context.py L12, risk.py L6 | 존재하지 않는 키 `market` 사용 | 모든 매크로 값 "N/A" |
| `mc.get("events", [])` | context.py L13 | `events` 키 없음 | 항상 빈 리스트 |
| `mc.get("risks", [])` | context.py L14 | `risks` 키 없음 | 항상 빈 리스트 |
| `mk.get("tnx")` | report.py L20 | 실제 키: `us10y` | 10Y 값 항상 None |
| `mk.get("vix")` | context.py L25 | VIX 수집 안 함 | 항상 "N/A" |
| `mk.get("gold")` | report.py L22 | Gold 수집 안 함 | 항상 None |

## 검증 방법
새 Phase를 추가하거나 데이터 구조를 변경했으면 실제 JSON 출력 파일을 읽어 키 목록을 확인:
```bash
python3 -c "import json; print(json.load(open('data/macro_context.json')).keys())"
python3 -c "import json; d=json.load(open('data/macro_context.json')); print(d.get('key_macro_data',{}).keys())"
```

---
name: self-healing-cron
description: General self-healing instructions for cron jobs — retry, diagnose, fix on error
category: devops
---

# Self-Healing Cron Instructions

When **any step in this cron job fails**, follow this protocol before reporting failure.

## 자가 치유 규칙 (HARD RULE)

1. **진단**: 에러 메시지, 로그, 파일 상태를 확인해 근본 원인 파악
2. **재시도**: 실패한 단계를 최대 2회 재시도 (네트워크 오류는 5초 delay 후)
3. **대안**: 재시도도 실패하면 다른 접근법 시도 (다른 API/툴/경로/파라미터)
4. **자동수정**: 명백한 원인이면 직접 수정 (파일 없음 → 생성, 경로 오류 → 수정, 패키지 없음 → pip install)
5. **보고**: 모든 시도 실패 시 → 에러 내용 + 시도한 조치 + 추정 원인 포함해 보고

## 자주 발생하는 오류 대처

| 오류 | 대처 |
|------|------|
| Network timeout | 5초 대기 후 재시도 (최대 2회) |
| Connection refused | 10초 후 재시도 (서비스 시작 대기) |
| File not found | 경로 확인, 필요한 경우 상위 디렉토리 생성 |
| Permission denied | chmod 또는 sudo 없이 우회 경로 탐색 |
| Python import error | `pip install <package>` 후 재시도 |
| Broken pipe | clarify 등 user-input 툴 호출 금지 확인. 스킬이 프롬프트보다 먼저 로드돼서 스킬 지침을 따를 수 있음 → 스킬 자체를 크론/인터랙티브 모드로 분리 필요. 프롬프트가 자급자족형(템플릿+로직 내장)이면 아예 해당 스킬을 크론 skills에서 제거 |
| API rate limit | 10초 대기 후 재시도 |
| Script non-zero exit | stderr 확인, 스크립트 의존성 점검 |

## 중요
- 첫 실패에서 포기하지 말 것. 최소 2회 재시도 또는 대안 접근 시도
- 자가 치유 시도는 최대 30초 이내로 제한 (크론 타임아웃 방지)
- 자가 치유 성공 시 결과에 "(자가 치유됨)" 표시

## 🚨 복구 불가 패턴: 프롬프트보다 스킬이 우선

**증상**: 크론이 계속 같은 에러로 실패(예: Broken pipe). 재시도/대안도 안 통함.

**원인**: 크론이 로드한 스킬의 지침이 프롬프트보다 우선순위로 동작.
- 예: daily-survey 스킬에 "clarify로 설문 진행" 지침이 있음
- 프롬프트가 "clarify 호출 금지"라고 해도, 스킬이 먼저 로드되면서 스킬 지침을 따름

**해결책**:
1. 스킬 구조 자체를 **크론 모드 vs 인터랙티브 모드**로 명확히 분리
2. 크론 모드 섹션: "절대 하지 말 것" 목록을 최상단에 배치 (묻히지 않게)
3. 스킬의 "실행 순서" 섹션은 인터랙티브 모드로만 제한
4. 크론 프롬프트는 툴 호출 자체를 전면 금지 + 텍스트 출력만
5. **최후 수단**: 크론 프롬프트가 자급자족형(템플릿+로직 내장)이면 아예 문제 되는 스킬을 크론 skills 배열에서 제거. 에이전트가 인터랙티브 지침을 볼 수 없게 원천 차단. (실제 사례: daily-survey 스킬을 survey-morning 크론에서 제거 → Broken pipe 해결)

## 🚫 크론 스케줄러 락 (stale .tick.lock)

**증상**: `cronjob run`으로 실행해도 새 출력 파일 안 생김. `last_status` 안 바뀜. `next_run_at`만 계속 밀림.

**진단**:
```bash
ls -la ~/.hermes/cron/.tick.lock
# 0바이트 파일이 1분 이상 남아있으면 stale lock
```

**치유**:
```bash
rm ~/.hermes/cron/.tick.lock
```
락 제거 후 다음 틱에서 정상 처리됨.

**발생 조건**: 크론 틱 도중 에러(Broken pipe 등)로 비정상 종료 → 락 파일 미정리

## ⏱️ cronjob run ≠ 즉시 실행

`cronjob run`은 **즉시 실행이 아니라 다음 틱(약 1분 후)에 스케줄링**한다.
- `last_run_at`은 스케줄이 실행된 후에만 갱신됨
- 즉시 테스트하려면 락 제거 후 `cronjob run` 실행 + 최소 1분 대기
- 또는 `no_agent=True` script로 테스트 (즉시 stdout 확인 가능)

## 📦 data-collection script 패턴

크론 에이전트가 파일/API 읽기를 직접 하면 툴 호출 실패 위험 존재. 대신 `script` 파라미터를 사용해 데이터 수집을 선처리:

```bash
# ~/.hermes/scripts/check_something.sh
#!/bin/bash
# stdout이 context로 주입됨
python3 -c "print('RESULT')"
```

크론 설정:
```
script: check_something.sh
prompt: "스크립트 결과(context) 보고 템플릿 출력. clarify/terminal/read_file 금지"
```

이렇게 하면 에이전트는 복잡한 판단 없이 주입된 context만 보고 텍스트를 출력하면 됨 → 툴 호출 0회, Broken pipe 위험 0.
